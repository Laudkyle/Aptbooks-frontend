import StatementsPage from "./StatementsPage";

// Alias kept to match router imports.
export default StatementsPage;
