export const ROLE_TEMPLATES = [
  { value: 'admin', label: 'Admin' },
  { value: 'accountant', label: 'Accountant' },
  { value: 'clerk', label: 'Clerk' },
  { value: 'viewer', label: 'Viewer' }
];
