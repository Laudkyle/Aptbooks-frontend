import { ROUTES } from '../constants/routes.js';

export const routeMeta = {
  [ROUTES.dashboard]: { title: 'Dashboard', breadcrumbs: ['Dashboard'] },
  [ROUTES.search]: { title: 'Search', breadcrumbs: ['Search'] },
  [ROUTES.notifications]: { title: 'Notifications', breadcrumbs: ['Inbox'] },
  [ROUTES.approvalsInbox]: { title: 'Approvals Inbox', breadcrumbs: ['Approvals', 'Inbox'] },
  [ROUTES.adminOrg]: { title: 'Organization', breadcrumbs: ['Admin', 'Organization'] },
  [ROUTES.adminUsers]: { title: 'Users', breadcrumbs: ['Admin', 'Users'] },
  [ROUTES.adminRoles]: { title: 'Roles', breadcrumbs: ['Admin', 'Roles'] },
  [ROUTES.adminPermissions]: { title: 'Permissions', breadcrumbs: ['Admin', 'Permissions'] },
  [ROUTES.adminSettings]: { title: 'Settings', breadcrumbs: ['Admin', 'Settings'] },
  [ROUTES.adminDimensionSecurity]: { title: 'Dimension Security', breadcrumbs: ['Admin', 'Dimension Security'] },
  [ROUTES.adminApiKeys]: { title: 'API Keys', breadcrumbs: ['Admin', 'API Keys'] },
  [ROUTES.utilitiesHealth]: { title: 'Health', breadcrumbs: ['Utilities', 'Health'] },

  [ROUTES.quotations]: { title: 'Quotations', breadcrumbs: ['Operations', 'Transactions', 'Quotations'] },
  [ROUTES.salesOrders]: { title: 'Sales Orders', breadcrumbs: ['Operations', 'Transactions', 'Sales Orders'] },
  [ROUTES.purchaseRequisitions]: { title: 'Purchase Requisitions', breadcrumbs: ['Operations', 'Transactions', 'Purchase Requisitions'] },
  [ROUTES.purchaseOrders]: { title: 'Purchase Orders', breadcrumbs: ['Operations', 'Transactions', 'Purchase Orders'] },
  [ROUTES.goodsReceipts]: { title: 'Goods Receipts', breadcrumbs: ['Operations', 'Transactions', 'Goods Receipts'] },
  [ROUTES.expenses]: { title: 'Expenses', breadcrumbs: ['Operations', 'Transactions', 'Expenses'] },
  [ROUTES.pettyCash]: { title: 'Petty Cash', breadcrumbs: ['Operations', 'Transactions', 'Petty Cash'] },
  [ROUTES.advances]: { title: 'Advances', breadcrumbs: ['Operations', 'Transactions', 'Advances'] },
  [ROUTES.returns]: { title: 'Returns', breadcrumbs: ['Operations', 'Transactions', 'Returns'] },
  [ROUTES.refunds]: { title: 'Refunds', breadcrumbs: ['Operations', 'Transactions', 'Refunds'] },

  [ROUTES.treasury]: { title: 'Treasury', breadcrumbs: ['Banking', 'Treasury'] },
  [ROUTES.treasuryDashboard]: { title: 'Treasury Dashboard', breadcrumbs: ['Banking', 'Treasury', 'Dashboard'] },
  [ROUTES.paymentRuns]: { title: 'Payment Runs', breadcrumbs: ['Banking', 'Treasury', 'Payment Runs'] },
  [ROUTES.bankTransfers]: { title: 'Bank Transfers', breadcrumbs: ['Banking', 'Treasury', 'Bank Transfers'] },
  [ROUTES.paymentApprovalBatches]: { title: 'Approval Batches', breadcrumbs: ['Banking', 'Treasury', 'Approval Batches'] },
  [ROUTES.cheques]: { title: 'Cheques', breadcrumbs: ['Banking', 'Treasury', 'Cheques'] },
  [ROUTES.cashForecast]: { title: 'Cash Forecast', breadcrumbs: ['Banking', 'Treasury', 'Cash Forecast'] },

  [ROUTES.automation]: { title: 'Automation', breadcrumbs: ['Automation'] },
  [ROUTES.automationRecurringTransactions]: { title: 'Recurring Transactions', breadcrumbs: ['Automation', 'Recurring Transactions'] },
  [ROUTES.automationAccountingJobs]: { title: 'Accounting Jobs', breadcrumbs: ['Automation', 'Accounting Jobs'] },
  [ROUTES.automationAutoReconciliation]: { title: 'Auto Reconciliation', breadcrumbs: ['Automation', 'Auto Reconciliation'] },
  [ROUTES.automationDocumentMatching]: { title: 'Document Matching', breadcrumbs: ['Automation', 'Document Matching'] },
  [ROUTES.automationAiClassification]: { title: 'AI Classification', breadcrumbs: ['Automation', 'AI Classification'] },
  [ROUTES.automationSmartNotifications]: { title: 'Smart Notifications', breadcrumbs: ['Automation', 'Smart Notifications'] }
};
