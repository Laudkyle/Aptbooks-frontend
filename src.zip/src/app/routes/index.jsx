import React, { Suspense, lazy } from "react";
import { createBrowserRouter, Navigate } from "react-router-dom";
import { ProtectedRoute, GuestRoute, PermissionGate } from "./route-guards.jsx";
import { ROUTES } from "../constants/routes.js";
import { PERMISSIONS } from "../constants/permissions.js";
import { AppShell } from "../../shared/components/layout/AppShell.jsx";

import Dashboard from "../../pages/Dashboard.jsx";
import Me from "../../pages/Me.jsx";
import NotFound from "../../pages/NotFound.jsx";
import Forbidden from "../../pages/Forbidden.jsx";

const Login = lazy(() => import("../../features/auth/pages/Login.jsx"));
const Register = lazy(() => import("../../features/auth/pages/Register.jsx"));
const ForgotPassword = lazy(() =>
  import("../../features/auth/pages/ForgotPassword.jsx")
);
const ResetPassword = lazy(() =>
  import("../../features/auth/pages/ResetPassword.jsx")
);

const GlobalSearch = lazy(() =>
  import("../../features/search/pages/GlobalSearch.jsx")
);
const NotificationCenter = lazy(() =>
  import("../../features/notifications/pages/NotificationCenter.jsx")
);
const ApprovalQueue = lazy(() =>
  import("../../features/workflow/approvals/pages/ApprovalQueue.jsx")
);

const OrganizationSettings = lazy(() =>
  import(
    "../../features/foundation/organizations/pages/OrganizationSettings.jsx"
  )
);
const UserList = lazy(() =>
  import("../../features/foundation/users/pages/UserList.jsx")
);
const UserDetail = lazy(() =>
  import("../../features/foundation/users/pages/UserDetail.jsx")
);
const RoleList = lazy(() =>
  import("../../features/foundation/roles/pages/RoleList.jsx")
);
const RoleDetail = lazy(() =>
  import("../../features/foundation/roles/pages/RoleDetail.jsx")
);
const PermissionMatrix = lazy(() =>
  import("../../features/foundation/permissions/pages/PermissionMatrix.jsx")
);
const SystemSettings = lazy(() =>
  import("../../features/foundation/settings/pages/SystemSettings.jsx")
);
const DimensionRules = lazy(() =>
  import("../../features/foundation/dimensionSecurity/pages/DimensionRules.jsx")
);
const ApiKeyList = lazy(() =>
  import("../../features/foundation/apiKeys/pages/ApiKeyList.jsx")
);

const SystemHealth = lazy(() =>
  import("../../features/utilities/pages/SystemHealth.jsx")
);
const ScheduledTasks = lazy(() =>
  import("../../features/utilities/pages/ScheduledTasks.jsx")
);
const ErrorLogs = lazy(() =>
  import("../../features/utilities/pages/ErrorLogs.jsx")
);
const ClientLogs = lazy(() =>
  import("../../features/utilities/pages/ClientLogs.jsx")
);
const I18nAdmin = lazy(() =>
  import("../../features/utilities/pages/I18nAdmin.jsx")
);
const A11yChecks = lazy(() =>
  import("../../features/utilities/pages/A11yChecks.jsx")
);
const ReleaseInfo = lazy(() =>
  import("../../features/utilities/pages/ReleaseInfo.jsx")
);
const TestConsole = lazy(() =>
  import("../../features/utilities/pages/TestConsole.jsx")
);

// Phase 8 — Banking
const BankingOverview = lazy(() =>
  import("../../features/banking/pages/BankingOverview.jsx")
);
const BankAccountsPage = lazy(() =>
  import("../../features/banking/pages/BankAccountsPage.jsx")
);
const BankStatementsPage = lazy(() =>
  import("../../features/banking/pages/BankStatementsPage.jsx")
);
const BankStatementDetailPage = lazy(() =>
  import("../../features/banking/pages/BankStatementDetailPage.jsx")
);
const BankMatchingRulesPage = lazy(() =>
  import("../../features/banking/pages/MatchingRulesPage.jsx")
);
const BankCashbookPage = lazy(() =>
  import("../../features/banking/pages/CashbookPage.jsx")
);
const BankReconciliationsPage = lazy(() =>
  import("../../features/banking/pages/ReconciliationsPage.jsx")
);
const TreasuryOverview = lazy(() =>
  import("../../features/banking/pages/TreasuryOverview.jsx")
);
const TreasuryDashboardPage = lazy(() =>
  import("../../features/banking/pages/TreasuryDashboardPage.jsx")
);
const PaymentRunsPage = lazy(() =>
  import("../../features/banking/pages/PaymentRunsPage.jsx")
);
const PaymentRunDetailPage = lazy(() =>
  import("../../features/banking/pages/PaymentRunDetailPage.jsx")
);
const BankTransfersPage = lazy(() =>
  import("../../features/banking/pages/BankTransfersPage.jsx")
);
const BankTransferDetailPage = lazy(() =>
  import("../../features/banking/pages/BankTransferDetailPage.jsx")
);
const ApprovalBatchesPage = lazy(() =>
  import("../../features/banking/pages/ApprovalBatchesPage.jsx")
);
const ApprovalBatchDetailPage = lazy(() =>
  import("../../features/banking/pages/ApprovalBatchDetailPage.jsx")
);
const ChequesPage = lazy(() =>
  import("../../features/banking/pages/ChequesPage.jsx")
);
const CashForecastPage = lazy(() =>
  import("../../features/banking/pages/CashForecastPage.jsx")
);

// Phase 9 — Automation
const AutomationOverview = lazy(() =>
  import("../../features/automation/pages/Overview.jsx")
);
const RecurringTransactionsPage = lazy(() =>
  import("../../features/automation/pages/RecurringTransactionsPage.jsx")
);
const AccountingJobsPage = lazy(() =>
  import("../../features/automation/pages/AccountingJobsPage.jsx")
);
const AutoReconciliationPage = lazy(() =>
  import("../../features/automation/pages/AutoReconciliationPage.jsx")
);
const DocumentMatchingPage = lazy(() =>
  import("../../features/automation/pages/DocumentMatchingPage.jsx")
);
const AIClassificationPage = lazy(() =>
  import("../../features/automation/pages/AIClassificationPage.jsx")
);
const SmartNotificationsPage = lazy(() =>
  import("../../features/automation/pages/SmartNotificationsPage.jsx")
);

// Phase 10 — Printing
const TemplatesPage = lazy(() =>
  import("../../features/printing/pages/TemplatesPage.jsx")
);
const PrintAssignmentsPage = lazy(() =>
  import("../../features/printing/pages/AssignmentsPage.jsx")
);
const PrintPreviewPage = lazy(() =>
  import("../../features/printing/pages/PreviewPage.jsx")
);

// Phase 8 — Compliance
const ComplianceOverview = lazy(() =>
  import("../../features/compliance/pages/ComplianceOverview.jsx")
);
const IFRS16LeasesPage = lazy(() =>
  import("../../features/compliance/pages/IFRS16LeasesPage.jsx")
);
const IFRS16LeaseDetailPage = lazy(() =>
  import("../../features/compliance/pages/IFRS16LeaseDetailPage.jsx")
);
const IFRS15ContractsPage = lazy(() =>
  import("../../features/compliance/pages/IFRS15ContractsPage.jsx")
);
const IFRS15ContractDetailPage = lazy(() =>
  import("../../features/compliance/pages/IFRS15ContractDetailPage.jsx")
);
const IFRS9EclPage = lazy(() =>
  import("../../features/compliance/pages/IFRS9ECLPage.jsx")
);
const IAS12TaxPage = lazy(() =>
  import("../../features/compliance/pages/IAS12TaxPage.jsx")
);

// Phase 8 — Workflow Documents
const DocumentsLibraryPage = lazy(() =>
  import("../../features/workflow/pages/DocumentsLibraryPage.jsx")
);
const DocumentDetailPage = lazy(() =>
  import("../../features/workflow/pages/DocumentDetailPage.jsx")
);
const DocumentTypesPage = lazy(() =>
  import("../../features/workflow/pages/DocumentTypesPage.jsx")
);
const ApprovalLevelsPage = lazy(() =>
  import("../../features/workflow/pages/ApprovalLevelsPage.jsx")
);
const DocumentCreatePage = lazy(() =>
  import("../../features/workflow/pages/DocumentCreatePage.jsx")
);

// Phase 4 — Accounting
const AccountList = lazy(() =>
  import("../../features/accounting/chartOfAccounts/pages/AccountList.jsx")
);
const AccountCreate = lazy(() =>
  import("../../features/accounting/chartOfAccounts/pages/AccountCreate.jsx")
);
const AccountDetail = lazy(() =>
  import("../../features/accounting/chartOfAccounts/pages/AccountDetail.jsx")
);

const PeriodList = lazy(() =>
  import("../../features/accounting/periods/pages/PeriodList.jsx")
);
const PeriodClose = lazy(() =>
  import("../../features/accounting/periods/pages/PeriodClose.jsx")
);

const JournalList = lazy(() =>
  import("../../features/accounting/journals/pages/JournalList.jsx")
);
const JournalCreate = lazy(() =>
  import("../../features/accounting/journals/pages/JournalCreate.jsx")
);
const JournalDetail = lazy(() =>
  import("../../features/accounting/journals/pages/JournalDetail.jsx")
);

const TrialBalance = lazy(() =>
  import("../../features/accounting/balances/pages/TrialBalance.jsx")
);
const BalanceByAccount = lazy(() =>
  import("../../features/accounting/balances/pages/BalanceByAccount.jsx")
);

const PnL = lazy(() =>
  import("../../features/accounting/statements/pages/PnL.jsx")
);
const BalanceSheet = lazy(() =>
  import("../../features/accounting/statements/pages/BalanceSheet.jsx")
);
const Cashflow = lazy(() =>
  import("../../features/accounting/statements/pages/Cashflow.jsx")
);
const ChangesInEquity = lazy(() =>
  import("../../features/accounting/statements/pages/ChangesInEquity.jsx")
);

const ExportsHub = lazy(() =>
  import("../../features/accounting/exports/pages/ExportsHub.jsx")
);
const ImportsHub = lazy(() =>
  import("../../features/accounting/imports/pages/ImportsHub.jsx")
);

const FxRates = lazy(() =>
  import("../../features/accounting/fx/pages/FxRates.jsx")
);
const TaxAdmin = lazy(() =>
  import("../../features/accounting/tax/pages/TaxAdmin.jsx")
);

const AccrualsHub = lazy(() =>
  import("../../features/accounting/accruals/pages/AccrualsHub.jsx")
);
const AccrualCreate = lazy(() =>
  import("../../features/accounting/accruals/pages/AccrualCreate.jsx")
);

const Reconciliation = lazy(() =>
  import("../../features/accounting/reconciliation/pages/Reconciliation.jsx")
);

// Phase 5 — Business / Transactions / AR Ops / Reporting
const Customers = lazy(() =>
  import("../../features/business/pages/Customers.jsx")
);
const Vendors = lazy(() => import("../../features/business/pages/Vendors.jsx"));
const PartnerDetail = lazy(() =>
  import("../../features/business/pages/PartnerDetail.jsx")
);
const PartnerCreate = lazy(() =>
  import("../../features/business/pages/PartnerCreate.jsx")
);
const PaymentConfig = lazy(() =>
  import("../../features/business/pages/PaymentConfig.jsx")
);

const InvoiceList = lazy(() =>
  import("../../features/transactions/pages/InvoiceList.jsx")
);
const InvoiceCreate = lazy(() =>
  import("../../features/transactions/pages/InvoiceCreate.jsx")
);
const InvoiceDetail = lazy(() =>
  import("../../features/transactions/pages/InvoiceDetail.jsx")
);

const BillList = lazy(() =>
  import("../../features/transactions/pages/BillList.jsx")
);
const BillCreate = lazy(() =>
  import("../../features/transactions/pages/BillCreate.jsx")
);
const BillDetail = lazy(() =>
  import("../../features/transactions/pages/BillDetail.jsx")
);

const CustomerReceiptList = lazy(() =>
  import("../../features/transactions/pages/CustomerReceiptList.jsx")
);
const CustomerReceiptCreate = lazy(() =>
  import("../../features/transactions/pages/CustomerReceiptCreate.jsx")
);
const CustomerReceiptDetail = lazy(() =>
  import("../../features/transactions/pages/CustomerReceiptDetail.jsx")
);

const VendorPaymentList = lazy(() =>
  import("../../features/transactions/pages/VendorPaymentList.jsx")
);
const VendorPaymentCreate = lazy(() =>
  import("../../features/transactions/pages/VendorPaymentCreate.jsx")
);
const VendorPaymentDetail = lazy(() =>
  import("../../features/transactions/pages/VendorPaymentDetail.jsx")
);

const CreditNoteList = lazy(() =>
  import("../../features/transactions/pages/CreditNoteList.jsx")
);
const CreditNoteCreate = lazy(() =>
  import("../../features/transactions/pages/CreditNoteCreate.jsx")
);
const CreditNoteDetail = lazy(() =>
  import("../../features/transactions/pages/CreditNoteDetail.jsx")
);

const DebitNoteList = lazy(() =>
  import("../../features/transactions/pages/DebitNoteList.jsx")
);
const DebitNoteCreate = lazy(() =>
  import("../../features/transactions/pages/DebitNoteCreate.jsx")
);
const DebitNoteDetail = lazy(() =>
  import("../../features/transactions/pages/DebitNoteDetail.jsx")
);

const QuotationList = lazy(() => import('../../features/transactions/pages/QuotationList.jsx'));
const QuotationCreate = lazy(() => import('../../features/transactions/pages/QuotationCreate.jsx'));
const QuotationDetail = lazy(() => import('../../features/transactions/pages/QuotationDetail.jsx'));
const SalesOrderList = lazy(() => import('../../features/transactions/pages/SalesOrderList.jsx'));
const SalesOrderCreate = lazy(() => import('../../features/transactions/pages/SalesOrderCreate.jsx'));
const SalesOrderDetail = lazy(() => import('../../features/transactions/pages/SalesOrderDetail.jsx'));
const PurchaseRequisitionList = lazy(() => import('../../features/transactions/pages/PurchaseRequisitionList.jsx'));
const PurchaseRequisitionCreate = lazy(() => import('../../features/transactions/pages/PurchaseRequisitionCreate.jsx'));
const PurchaseRequisitionDetail = lazy(() => import('../../features/transactions/pages/PurchaseRequisitionDetail.jsx'));
const PurchaseOrderList = lazy(() => import('../../features/transactions/pages/PurchaseOrderList.jsx'));
const PurchaseOrderCreate = lazy(() => import('../../features/transactions/pages/PurchaseOrderCreate.jsx'));
const PurchaseOrderDetail = lazy(() => import('../../features/transactions/pages/PurchaseOrderDetail.jsx'));
const GoodsReceiptList = lazy(() => import('../../features/transactions/pages/GoodsReceiptList.jsx'));
const GoodsReceiptCreate = lazy(() => import('../../features/transactions/pages/GoodsReceiptCreate.jsx'));
const GoodsReceiptDetail = lazy(() => import('../../features/transactions/pages/GoodsReceiptDetail.jsx'));
const ExpenseList = lazy(() => import('../../features/transactions/pages/ExpenseList.jsx'));
const ExpenseCreate = lazy(() => import('../../features/transactions/pages/ExpenseCreate.jsx'));
const ExpenseDetail = lazy(() => import('../../features/transactions/pages/ExpenseDetail.jsx'));
const PettyCashList = lazy(() => import('../../features/transactions/pages/PettyCashList.jsx'));
const PettyCashCreate = lazy(() => import('../../features/transactions/pages/PettyCashCreate.jsx'));
const PettyCashDetail = lazy(() => import('../../features/transactions/pages/PettyCashDetail.jsx'));
const AdvanceList = lazy(() => import('../../features/transactions/pages/AdvanceList.jsx'));
const AdvanceCreate = lazy(() => import('../../features/transactions/pages/AdvanceCreate.jsx'));
const AdvanceDetail = lazy(() => import('../../features/transactions/pages/AdvanceDetail.jsx'));
const ReturnList = lazy(() => import('../../features/transactions/pages/ReturnList.jsx'));
const ReturnCreate = lazy(() => import('../../features/transactions/pages/ReturnCreate.jsx'));
const ReturnDetail = lazy(() => import('../../features/transactions/pages/ReturnDetail.jsx'));
const RefundList = lazy(() => import('../../features/transactions/pages/RefundList.jsx'));
const RefundCreate = lazy(() => import('../../features/transactions/pages/RefundCreate.jsx'));
const RefundDetail = lazy(() => import('../../features/transactions/pages/RefundDetail.jsx'));

const CollectionsHub = lazy(() =>
  import("../../features/ar/pages/CollectionsHub.jsx")
);
const Disputes = lazy(() => import("../../features/ar/pages/Disputes.jsx"));
const Writeoffs = lazy(() => import("../../features/ar/pages/Writeoffs.jsx"));
const PaymentPlans = lazy(() =>
  import("../../features/ar/pages/PaymentPlans.jsx")
);

const ReportArAging = lazy(() =>
  import("../../features/reporting/pages/ReportArAging.jsx")
);
const ReportArOpenItems = lazy(() =>
  import("../../features/reporting/pages/ReportArOpenItems.jsx")
);
const ReportArCustomerStatement = lazy(() =>
  import("../../features/reporting/pages/ReportArCustomerStatement.jsx")
);
const ReportApAging = lazy(() =>
  import("../../features/reporting/pages/ReportApAging.jsx")
);
const ReportApOpenItems = lazy(() =>
  import("../../features/reporting/pages/ReportApOpenItems.jsx")
);
const ReportApVendorStatement = lazy(() =>
  import("../../features/reporting/pages/ReportApVendorStatement.jsx")
);
const ReportTax = lazy(() =>
  import("../../features/reporting/pages/ReportTax.jsx")
);

// Phase 6 — Assets + Inventory
const AssetRegister = lazy(() =>
  import("../../features/assets/pages/AssetRegister.jsx")
);
const AssetCategories = lazy(() =>
  import("../../features/assets/pages/AssetCategories.jsx")
);
const AssetDetail = lazy(() =>
  import("../../features/assets/pages/AssetDetail.jsx")
);
const AssetDepreciation = lazy(() =>
  import("../../features/assets/pages/AssetDepreciation.jsx")
);
const DepreciationRuns = lazy(() =>
  import("../../features/assets/pages/DepreciationRuns.jsx")
);
const AssetRegisterNew = lazy(() =>
  import("../../features/assets/pages/FixedAssetCreate.jsx")
);
const AssetCategoryNew = lazy(() =>
  import("../../features/assets/pages/AssetCategoryCreate.jsx")
);
const AssetCategoryEdit = lazy(() =>
  import("../../features/assets/pages/AssetCategoryEdit.jsx")
);
const AssetAcquire = lazy(() =>
  import("../../features/assets/pages/AssetAcquire.jsx")
);
const AssetDispose = lazy(() =>
  import("../../features/assets/pages/AssetDispose.jsx")
);
const AssetTransfer = lazy(() =>
  import("../../features/assets/pages/AssetTransfer.jsx")
);
const AssetRevalue = lazy(() =>
  import("../../features/assets/pages/AssetRevalue.jsx")
);
const AssetImpair = lazy(() =>
  import("../../features/assets/pages/AssetImpair.jsx")
);
const DepreciationScheduleNew = lazy(() =>
  import("../../features/assets/pages/DepreciationScheduleCreate.jsx")
);

const InventoryCategoryNew = lazy(() =>
  import("../../features/inventory/pages/CategoryCreate.jsx")
);
const InventoryUnitNew = lazy(() =>
  import("../../features/inventory/pages/UnitCreate.jsx")
);
const InventoryItemNew = lazy(() =>
  import("../../features/inventory/pages/ItemCreate.jsx")
);
const InventoryWarehouseNew = lazy(() =>
  import("../../features/inventory/pages/WarehouseCreate.jsx")
);
const InventoryTransactionNew = lazy(() =>
  import("../../features/inventory/pages/TransactionCreate.jsx")
);
const InventoryStockCountNew = lazy(() =>
  import("../../features/inventory/pages/StockCountCreate.jsx")
);
const InventoryItems = lazy(() =>
  import("../../features/inventory/pages/Items.jsx")
);
const InventoryWarehouses = lazy(() =>
  import("../../features/inventory/pages/Warehouses.jsx")
);
const InventoryCategories = lazy(() =>
  import("../../features/inventory/pages/Categories.jsx")
);
const InventoryUnits = lazy(() =>
  import("../../features/inventory/pages/Units.jsx")
);
const InventoryTransactions = lazy(() =>
  import("../../features/inventory/pages/Transactions.jsx")
);
const InventoryTransactionDetail = lazy(() =>
  import("../../features/inventory/pages/TransactionDetail.jsx")
);
const InventoryStockCounts = lazy(() =>
  import("../../features/inventory/pages/StockCounts.jsx")
);
const InventoryStockCountDetail = lazy(() =>
  import("../../features/inventory/pages/StockCountDetail.jsx")
);
const InventoryReports = lazy(() =>
  import("../../features/inventory/pages/Reports.jsx")
);
const InventoryBins = lazy(() =>
  import("../../features/inventory/pages/Bins.jsx")
);
const InventoryBinNew = lazy(() =>
  import("../../features/inventory/pages/BinCreate.jsx")
);
const InventoryReservations = lazy(() =>
  import("../../features/inventory/pages/Reservations.jsx")
);
const InventoryReservationNew = lazy(() =>
  import("../../features/inventory/pages/ReservationCreate.jsx")
);
const InventoryTransfers = lazy(() =>
  import("../../features/inventory/pages/Transfers.jsx")
);
const InventoryTransferNew = lazy(() =>
  import("../../features/inventory/pages/TransferCreate.jsx")
);
const InventoryTransferDetail = lazy(() =>
  import("../../features/inventory/pages/TransferDetail.jsx")
);
const InventoryTraceability = lazy(() =>
  import("../../features/inventory/pages/Traceability.jsx")
);
const InventoryReorder = lazy(() =>
  import("../../features/inventory/pages/Reorder.jsx")
);

// Phase 7 — Reporting & Planning
const Centers = lazy(() =>
  import("../../features/reporting/pages/Centers.jsx")
);
const Projects = lazy(() =>
  import("../../features/reporting/pages/Projects.jsx")
);
const ProjectDetail = lazy(() =>
  import("../../features/reporting/pages/ProjectDetail.jsx")
);
const Budgets = lazy(() =>
  import("../../features/reporting/pages/Budgets.jsx")
);
const BudgetDetail = lazy(() =>
  import("../../features/reporting/pages/BudgetDetail.jsx")
);
const Forecasts = lazy(() =>
  import("../../features/reporting/pages/Forecasts.jsx")
);
const ForecastDetail = lazy(() =>
  import("../../features/reporting/pages/ForecastDetail.jsx")
);
const Allocations = lazy(() =>
  import("../../features/reporting/pages/Allocations.jsx")
);
const KPIs = lazy(() => import("../../features/reporting/pages/KPIs.jsx"));
const Dashboards = lazy(() =>
  import("../../features/reporting/pages/Dashboards.jsx")
);
const SavedReports = lazy(() =>
  import("../../features/reporting/pages/SavedReports.jsx")
);
const ManagementReports = lazy(() =>
  import("../../features/reporting/pages/ManagementReports.jsx")
);

function Loader() {
  return <div className="p-4 text-sm text-text-muted">Loading…</div>;
}

function Lazy({ children }) {
  return <Suspense fallback={<Loader />}>{children}</Suspense>;
}

function RequirePermission({ any, all, children }) {
  return (
    <PermissionGate any={any} all={all} fallback={<Forbidden />}>
      {children}
    </PermissionGate>
  );
}

export const router = createBrowserRouter([
  {
    element: <GuestRoute />,
    children: [
      {
        path: ROUTES.login,
        element: (
          <Lazy>
            <Login />
          </Lazy>
        ),
      },
      {
        path: ROUTES.register,
        element: (
          <Lazy>
            <Register />
          </Lazy>
        ),
      },
      {
        path: ROUTES.forgotPassword,
        element: (
          <Lazy>
            <ForgotPassword />
          </Lazy>
        ),
      },
      {
        path: ROUTES.resetPassword,
        element: (
          <Lazy>
            <ResetPassword />
          </Lazy>
        ),
      },
    ],
  },
  {
    element: <ProtectedRoute />,
    children: [
      {
        element: <AppShell />,
        children: [
          { path: ROUTES.dashboard, element: <Dashboard /> },
          { path: ROUTES.me, element: <Me /> },

          {
            path: ROUTES.search,
            element: (
              <Lazy>
                <GlobalSearch />
              </Lazy>
            ),
          },
          {
            path: ROUTES.notifications,
            element: (
              <Lazy>
                <NotificationCenter />
              </Lazy>
            ),
          },
          {
            path: ROUTES.approvalsInbox,
            element: (
              <Lazy>
                <ApprovalQueue />
              </Lazy>
            ),
          },

          // Phase 4 — Accounting
          {
            path: ROUTES.accountingCoa,
            element: (
              <Lazy>
                <AccountList />
              </Lazy>
            ),
          },
          {
            path: ROUTES.accountingCoaNew,
            element: (
              <Lazy>
                <AccountCreate />
              </Lazy>
            ),
          },
          {
            path: ROUTES.accountingCoaDetail(),
            element: (
              <Lazy>
                <AccountDetail />
              </Lazy>
            ),
          },
          {
            path: ROUTES.accountingCoaEdit(),
            element: (
              <Lazy>
                <AccountDetail mode="edit" />
              </Lazy>
            ),
          },

          {
            path: ROUTES.accountingPeriods,
            element: (
              <Lazy>
                <PeriodList />
              </Lazy>
            ),
          },
          {
            path: ROUTES.accountingPeriodClose(),
            element: (
              <Lazy>
                <PeriodClose />
              </Lazy>
            ),
          },

          {
            path: ROUTES.accountingJournals,
            element: (
              <Lazy>
                <JournalList />
              </Lazy>
            ),
          },
          {
            path: ROUTES.accountingJournalNew,
            element: (
              <Lazy>
                <JournalCreate />
              </Lazy>
            ),
          },
          {
            path: ROUTES.accountingJournalDetail(),
            element: (
              <Lazy>
                <JournalDetail />
              </Lazy>
            ),
          },

          {
            path: ROUTES.accountingTrialBalance,
            element: (
              <Lazy>
                <TrialBalance />
              </Lazy>
            ),
          },
          {
            path: ROUTES.accountingAccountActivity,
            element: (
              <Lazy>
                <BalanceByAccount />
              </Lazy>
            ),
          },

          {
            path: ROUTES.accountingPnL,
            element: (
              <Lazy>
                <PnL />
              </Lazy>
            ),
          },
          {
            path: ROUTES.accountingBalanceSheet,
            element: (
              <Lazy>
                <BalanceSheet />
              </Lazy>
            ),
          },
          {
            path: ROUTES.accountingCashflow,
            element: (
              <Lazy>
                <Cashflow />
              </Lazy>
            ),
          },
          {
            path: ROUTES.accountingChangesEquity,
            element: (
              <Lazy>
                <ChangesInEquity />
              </Lazy>
            ),
          },

          {
            path: ROUTES.accountingExports,
            element: (
              <Lazy>
                <ExportsHub />
              </Lazy>
            ),
          },
          {
            path: ROUTES.accountingImports,
            element: (
              <Lazy>
                <ImportsHub />
              </Lazy>
            ),
          },

          {
            path: ROUTES.accountingFx,
            element: (
              <Lazy>
                <FxRates />
              </Lazy>
            ),
          },

          {
            path: ROUTES.accountingTax,
            element: (
              <RequirePermission any={[PERMISSIONS.taxRead]}>
                <Lazy>
                  <TaxAdmin />
                </Lazy>
              </RequirePermission>
            ),
          },

          {
            path: ROUTES.accountingAccruals,
            element: (
              <Lazy>
                <AccrualsHub />
              </Lazy>
            ),
          },
          {
            path: ROUTES.accountingAccrualNew,
            element: (
              <Lazy>
                <AccrualCreate />
              </Lazy>
            ),
          },

          {
            path: ROUTES.accountingReconciliation,
            element: (
              <Lazy>
                <Reconciliation />
              </Lazy>
            ),
          },

          // Phase 5 — Business
          {
            path: ROUTES.businessCustomers,
            element: (
              <RequirePermission
                any={[PERMISSIONS.partnersRead, PERMISSIONS.partnersManage]}
              >
                <Lazy>
                  <Customers />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.businessVendors,
            element: (
              <RequirePermission
                any={[PERMISSIONS.partnersRead, PERMISSIONS.partnersManage]}
              >
                <Lazy>
                  <Vendors />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.businessPartnerNew,
            element: (
              <RequirePermission any={[PERMISSIONS.partnersManage]}>
                <Lazy>
                  <PartnerCreate />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.businessPartnerDetail(),
            element: (
              <RequirePermission
                any={[PERMISSIONS.partnersRead, PERMISSIONS.partnersManage]}
              >
                <Lazy>
                  <PartnerDetail />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.businessPaymentConfig,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.paymentConfigManage,
                  PERMISSIONS.partnersRead,
                ]}
              >
                <Lazy>
                  <PaymentConfig />
                </Lazy>
              </RequirePermission>
            ),
          },

          // Phase 5 — Transactions
          {
            path: ROUTES.invoices,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.transactionsInvoiceRead,
                  PERMISSIONS.transactionsInvoiceManage,
                ]}
              >
                <Lazy>
                  <InvoiceList />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.invoiceNew,
            element: (
              <RequirePermission any={[PERMISSIONS.transactionsInvoiceManage]}>
                <Lazy>
                  <InvoiceCreate />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.invoiceDetail(),
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.transactionsInvoiceRead,
                  PERMISSIONS.transactionsInvoiceManage,
                ]}
              >
                <Lazy>
                  <InvoiceDetail />
                </Lazy>
              </RequirePermission>
            ),
          },

          {
            path: ROUTES.bills,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.transactionsBillRead,
                  PERMISSIONS.transactionsBillManage,
                ]}
              >
                <Lazy>
                  <BillList />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.billNew,
            element: (
              <RequirePermission any={[PERMISSIONS.transactionsBillManage]}>
                <Lazy>
                  <BillCreate />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.billDetail(),
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.transactionsBillRead,
                  PERMISSIONS.transactionsBillManage,
                ]}
              >
                <Lazy>
                  <BillDetail />
                </Lazy>
              </RequirePermission>
            ),
          },

          {
            path: ROUTES.customerReceipts,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.customerReceiptRead,
                  PERMISSIONS.customerReceiptManage,
                ]}
              >
                <Lazy>
                  <CustomerReceiptList />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.customerReceiptNew,
            element: (
              <RequirePermission any={[PERMISSIONS.customerReceiptManage]}>
                <Lazy>
                  <CustomerReceiptCreate />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.customerReceiptDetail(),
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.customerReceiptRead,
                  PERMISSIONS.customerReceiptManage,
                ]}
              >
                <Lazy>
                  <CustomerReceiptDetail />
                </Lazy>
              </RequirePermission>
            ),
          },

          {
            path: ROUTES.vendorPayments,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.vendorPaymentRead,
                  PERMISSIONS.vendorPaymentManage,
                ]}
              >
                <Lazy>
                  <VendorPaymentList />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.vendorPaymentNew,
            element: (
              <RequirePermission any={[PERMISSIONS.vendorPaymentManage]}>
                <Lazy>
                  <VendorPaymentCreate />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.vendorPaymentDetail(),
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.vendorPaymentRead,
                  PERMISSIONS.vendorPaymentManage,
                ]}
              >
                <Lazy>
                  <VendorPaymentDetail />
                </Lazy>
              </RequirePermission>
            ),
          },

          {
            path: ROUTES.creditNotes,
            element: (
              <RequirePermission
                any={[PERMISSIONS.creditNoteRead, PERMISSIONS.creditNoteManage]}
              >
                <Lazy>
                  <CreditNoteList />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.creditNoteNew,
            element: (
              <RequirePermission any={[PERMISSIONS.creditNoteManage]}>
                <Lazy>
                  <CreditNoteCreate />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.creditNoteDetail(),
            element: (
              <RequirePermission
                any={[PERMISSIONS.creditNoteRead, PERMISSIONS.creditNoteManage]}
              >
                <Lazy>
                  <CreditNoteDetail />
                </Lazy>
              </RequirePermission>
            ),
          },

          {
            path: ROUTES.debitNotes,
            element: (
              <RequirePermission
                any={[PERMISSIONS.debitNoteRead, PERMISSIONS.debitNoteManage]}
              >
                <Lazy>
                  <DebitNoteList />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.debitNoteNew,
            element: (
              <RequirePermission any={[PERMISSIONS.debitNoteManage]}>
                <Lazy>
                  <DebitNoteCreate />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.debitNoteDetail(),
            element: (
              <RequirePermission
                any={[PERMISSIONS.debitNoteRead, PERMISSIONS.debitNoteManage]}
              >
                <Lazy>
                  <DebitNoteDetail />
                </Lazy>
              </RequirePermission>
            ),
          },

          { path: ROUTES.quotations, element: (<RequirePermission any={[PERMISSIONS.quotationRead, PERMISSIONS.quotationManage]}><Lazy><QuotationList /></Lazy></RequirePermission>) },
          { path: ROUTES.quotationNew, element: (<RequirePermission any={[PERMISSIONS.quotationManage]}><Lazy><QuotationCreate /></Lazy></RequirePermission>) },
          { path: ROUTES.quotationDetail(), element: (<RequirePermission any={[PERMISSIONS.quotationRead, PERMISSIONS.quotationManage]}><Lazy><QuotationDetail /></Lazy></RequirePermission>) },

          { path: ROUTES.salesOrders, element: (<RequirePermission any={[PERMISSIONS.salesOrderRead, PERMISSIONS.salesOrderManage]}><Lazy><SalesOrderList /></Lazy></RequirePermission>) },
          { path: ROUTES.salesOrderNew, element: (<RequirePermission any={[PERMISSIONS.salesOrderManage]}><Lazy><SalesOrderCreate /></Lazy></RequirePermission>) },
          { path: ROUTES.salesOrderDetail(), element: (<RequirePermission any={[PERMISSIONS.salesOrderRead, PERMISSIONS.salesOrderManage]}><Lazy><SalesOrderDetail /></Lazy></RequirePermission>) },

          { path: ROUTES.purchaseRequisitions, element: (<RequirePermission any={[PERMISSIONS.purchaseRequisitionRead, PERMISSIONS.purchaseRequisitionManage]}><Lazy><PurchaseRequisitionList /></Lazy></RequirePermission>) },
          { path: ROUTES.purchaseRequisitionNew, element: (<RequirePermission any={[PERMISSIONS.purchaseRequisitionManage]}><Lazy><PurchaseRequisitionCreate /></Lazy></RequirePermission>) },
          { path: ROUTES.purchaseRequisitionDetail(), element: (<RequirePermission any={[PERMISSIONS.purchaseRequisitionRead, PERMISSIONS.purchaseRequisitionManage]}><Lazy><PurchaseRequisitionDetail /></Lazy></RequirePermission>) },

          { path: ROUTES.purchaseOrders, element: (<RequirePermission any={[PERMISSIONS.purchaseOrderRead, PERMISSIONS.purchaseOrderManage]}><Lazy><PurchaseOrderList /></Lazy></RequirePermission>) },
          { path: ROUTES.purchaseOrderNew, element: (<RequirePermission any={[PERMISSIONS.purchaseOrderManage]}><Lazy><PurchaseOrderCreate /></Lazy></RequirePermission>) },
          { path: ROUTES.purchaseOrderDetail(), element: (<RequirePermission any={[PERMISSIONS.purchaseOrderRead, PERMISSIONS.purchaseOrderManage]}><Lazy><PurchaseOrderDetail /></Lazy></RequirePermission>) },

          { path: ROUTES.goodsReceipts, element: (<RequirePermission any={[PERMISSIONS.goodsReceiptRead, PERMISSIONS.goodsReceiptManage]}><Lazy><GoodsReceiptList /></Lazy></RequirePermission>) },
          { path: ROUTES.goodsReceiptNew, element: (<RequirePermission any={[PERMISSIONS.goodsReceiptManage]}><Lazy><GoodsReceiptCreate /></Lazy></RequirePermission>) },
          { path: ROUTES.goodsReceiptDetail(), element: (<RequirePermission any={[PERMISSIONS.goodsReceiptRead, PERMISSIONS.goodsReceiptManage]}><Lazy><GoodsReceiptDetail /></Lazy></RequirePermission>) },

          { path: ROUTES.expenses, element: (<RequirePermission any={[PERMISSIONS.expenseRead, PERMISSIONS.expenseManage]}><Lazy><ExpenseList /></Lazy></RequirePermission>) },
          { path: ROUTES.expenseNew, element: (<RequirePermission any={[PERMISSIONS.expenseManage]}><Lazy><ExpenseCreate /></Lazy></RequirePermission>) },
          { path: ROUTES.expenseDetail(), element: (<RequirePermission any={[PERMISSIONS.expenseRead, PERMISSIONS.expenseManage]}><Lazy><ExpenseDetail /></Lazy></RequirePermission>) },

          { path: ROUTES.pettyCash, element: (<RequirePermission any={[PERMISSIONS.pettyCashRead, PERMISSIONS.pettyCashManage]}><Lazy><PettyCashList /></Lazy></RequirePermission>) },
          { path: ROUTES.pettyCashNew, element: (<RequirePermission any={[PERMISSIONS.pettyCashManage]}><Lazy><PettyCashCreate /></Lazy></RequirePermission>) },
          { path: ROUTES.pettyCashDetail(), element: (<RequirePermission any={[PERMISSIONS.pettyCashRead, PERMISSIONS.pettyCashManage]}><Lazy><PettyCashDetail /></Lazy></RequirePermission>) },

          { path: ROUTES.advances, element: (<RequirePermission any={[PERMISSIONS.advanceRead, PERMISSIONS.advanceManage]}><Lazy><AdvanceList /></Lazy></RequirePermission>) },
          { path: ROUTES.advanceNew, element: (<RequirePermission any={[PERMISSIONS.advanceManage]}><Lazy><AdvanceCreate /></Lazy></RequirePermission>) },
          { path: ROUTES.advanceDetail(), element: (<RequirePermission any={[PERMISSIONS.advanceRead, PERMISSIONS.advanceManage]}><Lazy><AdvanceDetail /></Lazy></RequirePermission>) },

          { path: ROUTES.returns, element: (<RequirePermission any={[PERMISSIONS.returnRead, PERMISSIONS.returnManage]}><Lazy><ReturnList /></Lazy></RequirePermission>) },
          { path: ROUTES.returnNew, element: (<RequirePermission any={[PERMISSIONS.returnManage]}><Lazy><ReturnCreate /></Lazy></RequirePermission>) },
          { path: ROUTES.returnDetail(), element: (<RequirePermission any={[PERMISSIONS.returnRead, PERMISSIONS.returnManage]}><Lazy><ReturnDetail /></Lazy></RequirePermission>) },

          { path: ROUTES.refunds, element: (<RequirePermission any={[PERMISSIONS.refundRead, PERMISSIONS.refundManage]}><Lazy><RefundList /></Lazy></RequirePermission>) },
          { path: ROUTES.refundNew, element: (<RequirePermission any={[PERMISSIONS.refundManage]}><Lazy><RefundCreate /></Lazy></RequirePermission>) },
          { path: ROUTES.refundDetail(), element: (<RequirePermission any={[PERMISSIONS.refundRead, PERMISSIONS.refundManage]}><Lazy><RefundDetail /></Lazy></RequirePermission>) },

          // Phase 5 — AR Ops
          {
            path: ROUTES.arCollections,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.collectionsRead,
                  PERMISSIONS.collectionsManage,
                ]}
              >
                <Lazy>
                  <CollectionsHub />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.arDunning,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.collectionsRead,
                  PERMISSIONS.collectionsManage,
                ]}
              >
                <Lazy>
                  <CollectionsHub />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.arDisputes,
            element: (
              <RequirePermission
                any={[PERMISSIONS.disputesRead, PERMISSIONS.disputesManage]}
              >
                <Lazy>
                  <Disputes />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.arWriteoffs,
            element: (
              <RequirePermission
                any={[PERMISSIONS.writeoffsRead, PERMISSIONS.writeoffsManage]}
              >
                <Lazy>
                  <Writeoffs />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.arPaymentPlans,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.paymentPlansRead,
                  PERMISSIONS.paymentPlansManage,
                ]}
              >
                <Lazy>
                  <PaymentPlans />
                </Lazy>
              </RequirePermission>
            ),
          },

          // Phase 5 — Reporting
          {
            path: ROUTES.reportArAging,
            element: (
              <RequirePermission any={[PERMISSIONS.reportingArRead]}>
                <Lazy>
                  <ReportArAging />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.reportArOpenItems,
            element: (
              <RequirePermission any={[PERMISSIONS.reportingArRead]}>
                <Lazy>
                  <ReportArOpenItems />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.reportArCustomerStatement,
            element: (
              <RequirePermission any={[PERMISSIONS.reportingArRead]}>
                <Lazy>
                  <ReportArCustomerStatement />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.reportApAging,
            element: (
              <RequirePermission any={[PERMISSIONS.reportingApRead]}>
                <Lazy>
                  <ReportApAging />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.reportApOpenItems,
            element: (
              <RequirePermission any={[PERMISSIONS.reportingApRead]}>
                <Lazy>
                  <ReportApOpenItems />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.reportApVendorStatement,
            element: (
              <RequirePermission any={[PERMISSIONS.reportingApRead]}>
                <Lazy>
                  <ReportApVendorStatement />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.reportTax,
            element: (
              <RequirePermission any={[PERMISSIONS.reportingTaxRead]}>
                <Lazy>
                  <ReportTax />
                </Lazy>
              </RequirePermission>
            ),
          },

          // Phase 6 — Assets
          {
            path: ROUTES.assetsCategories,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.assetsCategoriesRead,
                  PERMISSIONS.assetsCategoriesManage,
                ]}
              >
                <Lazy>
                  <AssetCategories />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.assetsRegister,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.assetsFixedAssetsRead,
                  PERMISSIONS.assetsFixedAssetsManage,
                ]}
              >
                <Lazy>
                  <AssetRegister />
                </Lazy>
              </RequirePermission>
            ),
          },

          {
            path: ROUTES.assetsRegisterNew,
            element: (
              <RequirePermission any={[PERMISSIONS.assetsFixedAssetsManage]}>
                <Lazy>
                  <AssetRegisterNew />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.assetsCategoriesNew,
            element: (
              <RequirePermission any={[PERMISSIONS.assetsCategoriesManage]}>
                <Lazy>
                  <AssetCategoryNew />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.assetsCategoryEdit(),
            element: (
              <RequirePermission any={[PERMISSIONS.assetsCategoriesManage]}>
                <Lazy>
                  <AssetCategoryEdit />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.assetsAssetAcquire(),
            element: (
              <RequirePermission any={[PERMISSIONS.assetsFixedAssetsManage]}>
                <Lazy>
                  <AssetAcquire />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.assetsAssetDispose(),
            element: (
              <RequirePermission any={[PERMISSIONS.assetsFixedAssetsManage]}>
                <Lazy>
                  <AssetDispose />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.assetsAssetTransfer(),
            element: (
              <RequirePermission any={[PERMISSIONS.assetsFixedAssetsManage]}>
                <Lazy>
                  <AssetTransfer />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.assetsAssetRevalue(),
            element: (
              <RequirePermission any={[PERMISSIONS.assetsFixedAssetsManage]}>
                <Lazy>
                  <AssetRevalue />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.assetsAssetImpair(),
            element: (
              <RequirePermission any={[PERMISSIONS.assetsFixedAssetsManage]}>
                <Lazy>
                  <AssetImpair />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.assetsAssetDeprScheduleNew(),
            element: (
              <RequirePermission any={[PERMISSIONS.assetsFixedAssetsManage]}>
                <Lazy>
                  <DepreciationScheduleNew />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.assetsAssetDetail(":id"),
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.assetsFixedAssetsRead,
                  PERMISSIONS.assetsFixedAssetsManage,
                ]}
              >
                <Lazy>
                  <AssetDetail />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.assetsDepreciation,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.assetsDepreciationRun,
                  PERMISSIONS.assetsFixedAssetsRead,
                ]}
              >
                <Lazy>
                  <AssetDepreciation />
                </Lazy>
              </RequirePermission>
            ),
          },

          // Phase 6 — Inventory
          {
            path: ROUTES.inventoryItems,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.inventoryItemsRead,
                  PERMISSIONS.inventoryItemsManage,
                ]}
              >
                <Lazy>
                  <InventoryItems />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryWarehouses,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.inventoryWarehousesRead,
                  PERMISSIONS.inventoryWarehousesManage,
                ]}
              >
                <Lazy>
                  <InventoryWarehouses />
                </Lazy>
              </RequirePermission>
            ),
          },

          {
            path: ROUTES.inventoryCategories,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.inventoryCategoriesRead,
                  PERMISSIONS.inventoryCategoriesManage,
                ]}
              >
                <Lazy>
                  <InventoryCategories />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryUnits,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.inventoryUnitsRead,
                  PERMISSIONS.inventoryUnitsManage,
                ]}
              >
                <Lazy>
                  <InventoryUnits />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryTransactions,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.inventoryTransactionsRead,
                  PERMISSIONS.inventoryTransactionsManage,
                  PERMISSIONS.inventoryTransactionsApprove,
                  PERMISSIONS.inventoryTransactionsPost,
                ]}
              >
                <Lazy>
                  <InventoryTransactions />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryTransactionDetail(":id"),
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.inventoryTransactionsRead,
                  PERMISSIONS.inventoryTransactionsManage,
                  PERMISSIONS.inventoryTransactionsApprove,
                  PERMISSIONS.inventoryTransactionsPost,
                ]}
              >
                <Lazy>
                  <InventoryTransactionDetail />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryStockCounts,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.inventoryTransactionsRead,
                  PERMISSIONS.inventoryTransactionsManage,
                  PERMISSIONS.inventoryTransactionsApprove,
                  PERMISSIONS.inventoryTransactionsPost,
                ]}
              >
                <Lazy>
                  <InventoryStockCounts />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryStockCountDetail(":id"),
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.inventoryTransactionsRead,
                  PERMISSIONS.inventoryTransactionsManage,
                  PERMISSIONS.inventoryTransactionsApprove,
                  PERMISSIONS.inventoryTransactionsPost,
                ]}
              >
                <Lazy>
                  <InventoryStockCountDetail />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryReports,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.inventoryTransactionsRead,
                  PERMISSIONS.inventoryTransactionsManage,
                ]}
              >
                <Lazy>
                  <InventoryReports />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryBins,
            element: (
              <RequirePermission any={[PERMISSIONS.inventoryWarehousesRead, PERMISSIONS.inventoryWarehousesManage]}>
                <Lazy><InventoryBins /></Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryReservations,
            element: (
              <RequirePermission any={[PERMISSIONS.inventoryReservationsRead, PERMISSIONS.inventoryReservationsManage]}>
                <Lazy><InventoryReservations /></Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryTransfers,
            element: (
              <RequirePermission any={[PERMISSIONS.inventoryTransfersRead, PERMISSIONS.inventoryTransfersManage, PERMISSIONS.inventoryTransfersApprove, PERMISSIONS.inventoryTransfersPost]}>
                <Lazy><InventoryTransfers /></Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryTransferDetail(":id"),
            element: (
              <RequirePermission any={[PERMISSIONS.inventoryTransfersRead, PERMISSIONS.inventoryTransfersManage, PERMISSIONS.inventoryTransfersApprove, PERMISSIONS.inventoryTransfersPost]}>
                <Lazy><InventoryTransferDetail /></Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryTraceability,
            element: (
              <RequirePermission any={[PERMISSIONS.inventoryTraceabilityRead, PERMISSIONS.inventoryTraceabilityManage]}>
                <Lazy><InventoryTraceability /></Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryReorder,
            element: (
              <RequirePermission any={[PERMISSIONS.inventoryReorderRead, PERMISSIONS.inventoryReorderManage]}>
                <Lazy><InventoryReorder /></Lazy>
              </RequirePermission>
            ),
          },

          // Phase 7 — Reporting & Planning
          {
            path: ROUTES.planningCenters("cost"),
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.reportingCentersRead,
                  PERMISSIONS.reportingCentersManage,
                ]}
              >
                <Lazy>
                  <Centers />
                </Lazy>
              </RequirePermission>
            ),
          },

          {
            path: ROUTES.inventoryCategoriesNew,
            element: (
              <RequirePermission any={[PERMISSIONS.inventoryCategoriesManage]}>
                <Lazy>
                  <InventoryCategoryNew />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryUnitsNew,
            element: (
              <RequirePermission any={[PERMISSIONS.inventoryUnitsManage]}>
                <Lazy>
                  <InventoryUnitNew />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryItemsNew,
            element: (
              <RequirePermission any={[PERMISSIONS.inventoryItemsManage]}>
                <Lazy>
                  <InventoryItemNew />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryWarehousesNew,
            element: (
              <RequirePermission any={[PERMISSIONS.inventoryWarehousesManage]}>
                <Lazy>
                  <InventoryWarehouseNew />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryTransactionsNew,
            element: (
              <RequirePermission
                any={[PERMISSIONS.inventoryTransactionsManage]}
              >
                <Lazy>
                  <InventoryTransactionNew />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryStockCountsNew,
            element: (
              <RequirePermission
                any={[PERMISSIONS.inventoryTransactionsManage]}
              >
                <Lazy>
                  <InventoryStockCountNew />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryBinsNew,
            element: (
              <RequirePermission any={[PERMISSIONS.inventoryWarehousesManage]}>
                <Lazy><InventoryBinNew /></Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryReservationsNew,
            element: (
              <RequirePermission any={[PERMISSIONS.inventoryReservationsManage]}>
                <Lazy><InventoryReservationNew /></Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.inventoryTransfersNew,
            element: (
              <RequirePermission any={[PERMISSIONS.inventoryTransfersManage]}>
                <Lazy><InventoryTransferNew /></Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.planningCenters("profit"),
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.reportingCentersRead,
                  PERMISSIONS.reportingCentersManage,
                ]}
              >
                <Lazy>
                  <Centers />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.planningCenters("investment"),
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.reportingCentersRead,
                  PERMISSIONS.reportingCentersManage,
                ]}
              >
                <Lazy>
                  <Centers />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.planningProjects,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.reportingProjectsRead,
                  PERMISSIONS.reportingProjectsManage,
                ]}
              >
                <Lazy>
                  <Projects />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.planningProjectDetail(":id"),
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.reportingProjectsRead,
                  PERMISSIONS.reportingProjectsManage,
                ]}
              >
                <Lazy>
                  <ProjectDetail />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.planningBudgets,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.reportingBudgetsRead,
                  PERMISSIONS.reportingBudgetsManage,
                ]}
              >
                <Lazy>
                  <Budgets />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.planningBudgetDetail(":id"),
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.reportingBudgetsRead,
                  PERMISSIONS.reportingBudgetsManage,
                ]}
              >
                <Lazy>
                  <BudgetDetail />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.planningForecasts,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.reportingForecastsRead,
                  PERMISSIONS.reportingForecastsManage,
                ]}
              >
                <Lazy>
                  <Forecasts />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.planningForecastDetail(":id"),
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.reportingForecastsRead,
                  PERMISSIONS.reportingForecastsManage,
                ]}
              >
                <Lazy>
                  <ForecastDetail />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.planningAllocations,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.reportingAllocationsRead,
                  PERMISSIONS.reportingAllocationsManage,
                ]}
              >
                <Lazy>
                  <Allocations />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.planningKpis,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.reportingKpisRead,
                  PERMISSIONS.reportingKpisManage,
                ]}
              >
                <Lazy>
                  <KPIs />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.planningDashboards,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.reportingDashboardsRead,
                  PERMISSIONS.reportingDashboardsManage,
                ]}
              >
                <Lazy>
                  <Dashboards />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.planningSavedReports,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.reportingReportsRead,
                  PERMISSIONS.reportingReportsManage,
                ]}
              >
                <Lazy>
                  <SavedReports />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.planningManagement,
            element: (
              <RequirePermission any={[PERMISSIONS.reportingManagementRead]}>
                <Lazy>
                  <ManagementReports />
                </Lazy>
              </RequirePermission>
            ),
          },

          // Admin
          {
            path: ROUTES.adminOrg,
            element: (
              <RequirePermission
                any={[PERMISSIONS.settingsRead, PERMISSIONS.settingsManage]}
              >
                <Lazy>
                  <OrganizationSettings />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.adminUsers,
            element: (
              <RequirePermission
                any={[PERMISSIONS.usersRead, PERMISSIONS.usersManage]}
              >
                <Lazy>
                  <UserList />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.adminUserDetail(),
            element: (
              <RequirePermission
                any={[PERMISSIONS.usersRead, PERMISSIONS.usersManage]}
              >
                <Lazy>
                  <UserDetail />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.adminRoles,
            element: (
              <RequirePermission
                any={[PERMISSIONS.rbacRolesRead, PERMISSIONS.rbacRolesManage]}
              >
                <Lazy>
                  <RoleList />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.adminRoleDetail(),
            element: (
              <RequirePermission
                any={[PERMISSIONS.rbacRolesRead, PERMISSIONS.rbacRolesManage]}
              >
                <Lazy>
                  <RoleDetail />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.adminPermissions,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.rbacPermissionsRead,
                  PERMISSIONS.rbacRolesRead,
                ]}
              >
                <Lazy>
                  <PermissionMatrix />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.adminSettings,
            element: (
              <RequirePermission
                any={[PERMISSIONS.settingsRead, PERMISSIONS.settingsManage]}
              >
                <Lazy>
                  <SystemSettings />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.adminDimensionSecurity,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.dimensionSecurityRead,
                  PERMISSIONS.dimensionSecurityManage,
                ]}
              >
                <Lazy>
                  <DimensionRules />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.adminApiKeys,
            element: (
              <RequirePermission
                any={[PERMISSIONS.settingsRead, PERMISSIONS.settingsManage]}
              >
                <Lazy>
                  <ApiKeyList />
                </Lazy>
              </RequirePermission>
            ),
          },

          // Utilities
          {
            path: ROUTES.utilitiesHealth,
            element: (
              <RequirePermission any={[PERMISSIONS.settingsRead]}>
                <Lazy>
                  <SystemHealth />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.utilitiesScheduler,
            element: (
              <RequirePermission any={[PERMISSIONS.settingsRead]}>
                <Lazy>
                  <ScheduledTasks />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.utilitiesErrors,
            element: (
              <RequirePermission any={[PERMISSIONS.settingsRead]}>
                <Lazy>
                  <ErrorLogs />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.utilitiesClientLogs,
            element: (
              <RequirePermission any={[PERMISSIONS.clientLogsRead]}>
                <Lazy>
                  <ClientLogs />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.utilitiesI18n,
            element: (
              <RequirePermission any={[PERMISSIONS.i18nRead]}>
                <Lazy>
                  <I18nAdmin />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.utilitiesA11y,
            element: (
              <RequirePermission any={[PERMISSIONS.a11yRead]}>
                <Lazy>
                  <A11yChecks />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.utilitiesRelease,
            element: (
              <RequirePermission any={[PERMISSIONS.releaseRead]}>
                <Lazy>
                  <ReleaseInfo />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.utilitiesTests,
            element: (
              <RequirePermission any={[PERMISSIONS.testsRun]}>
                <Lazy>
                  <TestConsole />
                </Lazy>
              </RequirePermission>
            ),
          },

          // Phase 8 — Banking
          {
            path: ROUTES.banking,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.bankingAccountsRead,
                  PERMISSIONS.bankingStatementsRead,
                ]}
              >
                <Lazy>
                  <BankingOverview />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.bankingAccounts,
            element: (
              <RequirePermission any={[PERMISSIONS.bankingAccountsRead]}>
                <Lazy>
                  <BankAccountsPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.bankingStatements,
            element: (
              <RequirePermission any={[PERMISSIONS.bankingStatementsRead]}>
                <Lazy>
                  <BankStatementsPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.bankingStatementDetail(),
            element: (
              <RequirePermission any={[PERMISSIONS.bankingStatementsRead]}>
                <Lazy>
                  <BankStatementDetailPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.bankingMatchingRules,
            element: (
              <RequirePermission any={[PERMISSIONS.bankingMatchingRulesManage]}>
                <Lazy>
                  <BankMatchingRulesPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.bankingCashbook,
            element: (
              <RequirePermission any={[PERMISSIONS.bankingCashbookRead]}>
                <Lazy>
                  <BankCashbookPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.bankingReconciliations,
            element: (
              <RequirePermission any={[PERMISSIONS.bankingReconciliationsRead]}>
                <Lazy>
                  <BankReconciliationsPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.treasury,
            element: (
              <RequirePermission any={[PERMISSIONS.bankingTreasuryRead]}>
                <Lazy>
                  <TreasuryOverview />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.treasuryDashboard,
            element: (
              <RequirePermission any={[PERMISSIONS.bankingTreasuryRead]}>
                <Lazy>
                  <TreasuryDashboardPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.paymentRuns,
            element: (
              <RequirePermission any={[PERMISSIONS.bankingTreasuryRead]}>
                <Lazy>
                  <PaymentRunsPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.paymentRunDetail(),
            element: (
              <RequirePermission any={[PERMISSIONS.bankingTreasuryRead]}>
                <Lazy>
                  <PaymentRunDetailPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.bankTransfers,
            element: (
              <RequirePermission any={[PERMISSIONS.bankingTreasuryRead]}>
                <Lazy>
                  <BankTransfersPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.bankTransferDetail(),
            element: (
              <RequirePermission any={[PERMISSIONS.bankingTreasuryRead]}>
                <Lazy>
                  <BankTransferDetailPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.paymentApprovalBatches,
            element: (
              <RequirePermission any={[PERMISSIONS.bankingTreasuryRead]}>
                <Lazy>
                  <ApprovalBatchesPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.paymentApprovalBatchDetail(),
            element: (
              <RequirePermission any={[PERMISSIONS.bankingTreasuryRead]}>
                <Lazy>
                  <ApprovalBatchDetailPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.cheques,
            element: (
              <RequirePermission any={[PERMISSIONS.bankingTreasuryRead]}>
                <Lazy>
                  <ChequesPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.cashForecast,
            element: (
              <RequirePermission any={[PERMISSIONS.bankingTreasuryRead]}>
                <Lazy>
                  <CashForecastPage />
                </Lazy>
              </RequirePermission>
            ),
          },

          {
            path: ROUTES.automation,
            element: (
              <RequirePermission any={[PERMISSIONS.automationRead, PERMISSIONS.automationManage]}>
                <Lazy>
                  <AutomationOverview />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.automationRecurringTransactions,
            element: (
              <RequirePermission any={[PERMISSIONS.automationRead, PERMISSIONS.automationManage]}>
                <Lazy>
                  <RecurringTransactionsPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.automationAccountingJobs,
            element: (
              <RequirePermission any={[PERMISSIONS.automationRead, PERMISSIONS.automationManage, PERMISSIONS.automationRun]}>
                <Lazy>
                  <AccountingJobsPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.automationAutoReconciliation,
            element: (
              <RequirePermission any={[PERMISSIONS.automationRead, PERMISSIONS.automationManage, PERMISSIONS.automationRun]}>
                <Lazy>
                  <AutoReconciliationPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.automationDocumentMatching,
            element: (
              <RequirePermission any={[PERMISSIONS.automationRead, PERMISSIONS.automationManage, PERMISSIONS.automationRun]}>
                <Lazy>
                  <DocumentMatchingPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.automationAiClassification,
            element: (
              <RequirePermission any={[PERMISSIONS.automationRead, PERMISSIONS.automationManage]}>
                <Lazy>
                  <AIClassificationPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.automationSmartNotifications,
            element: (
              <RequirePermission any={[PERMISSIONS.automationRead, PERMISSIONS.automationNotificationsManage, PERMISSIONS.automationManage]}>
                <Lazy>
                  <SmartNotificationsPage />
                </Lazy>
              </RequirePermission>
            ),
          },

          // Phase 10 — Printing
          {
            path: ROUTES.printingTemplates,
            element: (
              <RequirePermission any={[PERMISSIONS.printingTemplatesRead, PERMISSIONS.printingTemplatesManage]}>
                <Lazy>
                  <TemplatesPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.printingAssignments,
            element: (
              <RequirePermission any={[PERMISSIONS.printingAssignmentsManage, PERMISSIONS.printingTemplatesManage]}>
                <Lazy>
                  <PrintAssignmentsPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.printingPreview(),
            element: (
              <RequirePermission any={[PERMISSIONS.printingRender, PERMISSIONS.printingTemplatesRead, PERMISSIONS.printingTemplatesManage]}>
                <Lazy>
                  <PrintPreviewPage />
                </Lazy>
              </RequirePermission>
            ),
          },

          // Phase 8 — Compliance
          {
            path: ROUTES.compliance,
            element: (
              <RequirePermission
                any={[
                  PERMISSIONS.complianceIfrs16Read,
                  PERMISSIONS.complianceIfrs15Read,
                  PERMISSIONS.complianceIfrs9Read,
                  PERMISSIONS.complianceIas12Read,
                ]}
              >
                <Lazy>
                  <ComplianceOverview />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.complianceIFRS16,
            element: (
              <RequirePermission any={[PERMISSIONS.complianceIfrs16Read]}>
                <Lazy>
                  <IFRS16LeasesPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.complianceIFRS16LeaseDetail(),
            element: (
              <RequirePermission any={[PERMISSIONS.complianceIfrs16Read]}>
                <Lazy>
                  <IFRS16LeaseDetailPage />
                </Lazy>
              </RequirePermission>
            ),
          },

          {
            path: ROUTES.complianceIFRS15,
            element: (
              <RequirePermission any={[PERMISSIONS.complianceIfrs15Read]}>
                <Lazy>
                  <IFRS15ContractsPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.complianceIFRS15ContractDetail(),
            element: (
              <RequirePermission any={[PERMISSIONS.complianceIfrs15Read]}>
                <Lazy>
                  <IFRS15ContractDetailPage />
                </Lazy>
              </RequirePermission>
            ),
          },

          {
            path: ROUTES.complianceIFRS9,
            element: (
              <RequirePermission any={[PERMISSIONS.complianceIfrs9Read]}>
                <Lazy>
                  <IFRS9EclPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.complianceIAS12,
            element: (
              <RequirePermission any={[PERMISSIONS.complianceIas12Read]}>
                <Lazy>
                  <IAS12TaxPage />
                </Lazy>
              </RequirePermission>
            ),
          },

          // Phase 8 — Workflow Documents
          {
            path: ROUTES.documents,
            element: (
              <RequirePermission any={[PERMISSIONS.documentsRead]}>
                <Lazy>
                  <DocumentsLibraryPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.documentCreate,
            element: (
              <RequirePermission any={[PERMISSIONS.documentsManage]}>
                <Lazy>
                  <DocumentCreatePage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.documentDetail(),
            element: (
              <RequirePermission any={[PERMISSIONS.documentsRead]}>
                <Lazy>
                  <DocumentDetailPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.documentTypes,
            element: (
              <RequirePermission any={[PERMISSIONS.documentsManage]}>
                <Lazy>
                  <DocumentTypesPage />
                </Lazy>
              </RequirePermission>
            ),
          },
          {
            path: ROUTES.documentApprovalLevels,
            element: (
              <RequirePermission any={[PERMISSIONS.documentsManage]}>
                <Lazy>
                  <ApprovalLevelsPage />
                </Lazy>
              </RequirePermission>
            ),
          },

          { path: "/forbidden", element: <Forbidden /> },
          { path: "*", element: <NotFound /> },
        ],
      },
    ],
  },
  { path: "*", element: <Navigate to={ROUTES.dashboard} replace /> },
]);
