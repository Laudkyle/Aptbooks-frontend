import React, { useMemo, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, FileText, Calendar, User, DollarSign } from 'lucide-react';

import { useApi } from '../../../shared/hooks/useApi.js';
import { qk } from '../../../shared/query/keys.js';
import { makeInvoicesApi } from '../api/invoices.api.js';
import { formatDate } from '../../../shared/utils/formatDate.js';
import { Button } from '../../../shared/components/ui/Button.jsx';
import { Modal } from '../../../shared/components/ui/Modal.jsx';
import { TransactionWorkflowActionBar } from '../components/TransactionWorkflowActionBar.jsx';
import { normalizeTransactionWorkflow } from '../workflow/normalizeTransactionWorkflow.js';
import { resolveTransactionActions } from '../workflow/resolveTransactionActions.js';
import { Textarea } from '../../../shared/components/ui/Textarea.jsx';
import { useToast } from '../../../shared/components/ui/Toast.jsx';

// Generate UUID v4
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

export default function InvoiceDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { http } = useApi();
  const api = useMemo(() => makeInvoicesApi(http), [http]);
  const qc = useQueryClient();
  const toast = useToast();

  const { data, isLoading } = useQuery({
    queryKey: qk.invoice(id),
    queryFn: () => api.get(id)
  });

  const invoice = data?.data ?? data;
  const [comment, setComment] = useState('');
  const [voidReason, setVoidReason] = useState('');
  const [action, setAction] = useState(null);

  const run = useMutation({
    mutationFn: async () => {
      // Generate a unique idempotency key for each action
      const idempotencyKey = generateUUID();
      
      if (action === 'submit') return api.submitForApproval(id, { idempotencyKey });
      if (action === 'approve') return api.approve(id, { comment }, { idempotencyKey });
      if (action === 'reject') return api.reject(id, { comment }, { idempotencyKey });
      if (action === 'issue') return api.issue(id, { idempotencyKey });
      if (action === 'void') return api.void(id, { reason: voidReason }, { idempotencyKey });
      throw new Error('Unknown action');
    },
    onSuccess: () => {
      toast.success('Action completed successfully');
      qc.invalidateQueries({ queryKey: qk.invoice(id) });
      setAction(null);
      setComment('');
      setVoidReason('');
    },
    onError: (e) => toast.error(e?.message ?? 'Action failed')
  });

  const record = invoice?.invoice ?? invoice;
  const workflowState = normalizeTransactionWorkflow({ type: 'invoice', entity: record, payload: invoice });
  const status = workflowState.businessStatus;
  const availableActions = resolveTransactionActions({ type: 'invoice', state: workflowState });
  const statusColors = {
    paid: 'bg-green-100 text-green-800 border-green-200',
    issued: 'bg-blue-100 text-blue-800 border-blue-200',
    voided: 'bg-red-100 text-red-800 border-red-200',
    draft: 'bg-amber-100 text-amber-800 border-amber-200',
    pending: 'bg-purple-100 text-purple-800 border-purple-200'
  };

  const calculateTotal = () => {
    if (!invoice?.lines) return 0;
    return invoice.lines.reduce((sum, line) => {
      return sum + ((line.quantity ?? 1) * (line.unit_price ?? 0));
    }, 0);
  };

  const total = calculateTotal();
  const currency = invoice?.invoice.currency_code || 'USD';
  
  // Helper function to format currency amounts
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  return (
    <div className="min-h-screen ">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <FileText className="h-7 w-7 text-text-body" />
                <h1 className="text-2xl font-bold text-text-strong">
                  {invoice?.invoice.invoiceNumber ?? invoice?.invoice.code ?? (isLoading ? 'Loading...' : 'Invoice')}
                </h1>
                <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border ${statusColors[status] || statusColors.draft}`}>
                  {status.charAt(0).toUpperCase() + status.slice(1)}
                </span>
              </div>
              <p className="text-sm text-text-muted">
                Invoice ID: {id}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button 
                variant="outline"
                onClick={() => navigate(-1)}
                className="border-border-subtle"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <TransactionWorkflowActionBar actions={availableActions} onAction={setAction} documentType="invoice" documentId={id} />

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Invoice Summary */}
            <div className="bg-surface-1 rounded-lg shadow-sm border border-border-subtle p-6">
              <h3 className="text-base font-semibold text-text-strong mb-5">Invoice Summary</h3>
              
              <div className="grid gap-4 md:grid-cols-2">
                <div className=" rounded-lg border border-border-subtle p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <User className="h-4 w-4 text-text-soft" />
                    <span className="text-xs font-medium text-text-muted">Customer</span>
                  </div>
                  <div className="text-sm font-semibold text-text-strong">
                    {invoice?.invoice.customer_name ?? '—'}
                  </div>
                </div>

                <div className=" rounded-lg border border-border-subtle p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="h-4 w-4 text-text-soft" />
                    <span className="text-xs font-medium text-text-muted">Dates</span>
                  </div>
                  <div className="text-sm font-semibold text-text-strong">
                    {formatDate(invoice?.invoice.invoice_date)} → {formatDate(invoice?.invoice.due_date)}
                  </div>
                </div>

                {invoice?.invoice.memo && (
                  <div className="md:col-span-2  rounded-lg border border-border-subtle p-4">
                    <div className="text-xs font-medium text-text-muted mb-2">Memo</div>
                    <div className="text-sm text-text-body">{invoice.invoice.memo}</div>
                  </div>
                )}
              </div>
            </div>

            {/* Line Items */}
            <div className="bg-surface-1 rounded-lg shadow-sm border border-border-subtle overflow-hidden">
              <div className="px-6 py-4  border-b border-border-subtle">
                <h3 className="text-base font-semibold text-text-strong">Line Items</h3>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className=" border-b border-border-subtle">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-text-body uppercase tracking-wider">
                        Description
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-text-body uppercase tracking-wider">
                        Qty
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-text-body uppercase tracking-wider">
                        Unit Price
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-text-body uppercase tracking-wider">
                        Revenue Account
                      </th>
                      <th className="px-6 py-3 text-right text-xs font-semibold text-text-body uppercase tracking-wider">
                        Total
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-surface-1 divide-y divide-border-subtle">
                    {(invoice?.lines ?? []).map((l, idx) => {
                      const lineTotal = (l.quantity ?? 1) * (l.unit_price ?? 0);
                      
                      return (
                        <tr key={idx} className="hover:">
                          <td className="px-6 py-4 text-sm text-text-strong">{l.description}</td>
                          <td className="px-6 py-4 text-sm text-text-body">{l.quantity ?? 1}</td>
                          <td className="px-6 py-4 text-sm text-text-body">
                            {formatCurrency(l.unit_price ?? 0)}
                          </td>
                          <td className="px-6 py-4 text-text-muted font-mono text-xs">
                            {l.revenue_account_id ? `${l.revenue_account_id.substring(0, 8)}...` : '—'}
                          </td>
                          <td className="px-6 py-4 text-sm font-semibold text-text-strong text-right">
                            {formatCurrency(lineTotal)}
                          </td>
                        </tr>
                      );
                    })}
                    {!(invoice?.lines ?? []).length ? (
                      <tr>
                        <td className="px-6 py-12 text-center text-sm text-text-muted" colSpan={5}>
                          No line items
                        </td>
                      </tr>
                    ) : null}
                  </tbody>
                  {(invoice?.lines ?? []).length > 0 && (
                    <tfoot className=" border-t-2 border-border-subtle">
                      <tr>
                        <td colSpan={4} className="px-6 py-4 text-right text-sm font-semibold text-text-strong">
                          Total:
                        </td>
                        <td className="px-6 py-4 text-right text-lg font-bold text-text-strong">
                          {formatCurrency(total)}
                        </td>
                      </tr>
                    </tfoot>
                  )}
                </table>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-surface-1 rounded-lg shadow-sm border border-border-subtle p-6">
              <div className="flex items-center gap-2 mb-4">
                <DollarSign className="h-5 w-5 text-green-600" />
                <h3 className="text-base font-semibold text-text-strong">Invoice Total</h3>
              </div>
              <div className="text-3xl font-bold text-text-strong mb-6">
                {formatCurrency(total)}
              </div>

              <div className="space-y-3 pt-4 border-t border-border-subtle">
                <div className="flex justify-between text-sm">
                  <span className="text-text-muted">Status</span>
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${statusColors[status] || statusColors.draft}`}>
                    {status.charAt(0).toUpperCase() + status.slice(1)}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-text-muted">Currency</span>
                  <span className="font-medium text-text-strong">{currency}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-text-muted">Line Items</span>
                  <span className="font-medium text-text-strong">{(invoice?.lines ?? []).length}</span>
                </div>
                {invoice?.invoice.invoice_date && (
                  <div className="flex justify-between text-sm">
                    <span className="text-text-muted">Invoice Date</span>
                    <span className="font-medium text-text-strong">{formatDate(invoice?.invoice.invoice_date)}</span>
                  </div>
                )}
                {invoice?.invoice.due_date && (
                  <div className="flex justify-between text-sm">
                    <span className="text-text-muted">Due Date</span>
                    <span className="font-medium text-text-strong">{formatDate(invoice?.invoice.due_date)}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Action Modals */}
      <Modal
        open={!!action}
        onClose={() => setAction(null)}
        title={
          action === 'submit'
            ? 'Submit for Approval'
            : action === 'approve'
              ? 'Approve Invoice'
              : action === 'reject'
                ? 'Reject Invoice'
                : action === 'issue'
                  ? 'Issue Invoice'
                  : action === 'void'
                    ? 'Void Invoice'
                    : 'Action'
        }
      >
        <div className="space-y-4">
          {action === 'approve' || action === 'reject' ? (
            <div>
              <label className="block text-sm font-medium text-text-body mb-2">
                Comment {action === 'reject' ? '(recommended)' : '(optional)'}
              </label>
              <Textarea 
                rows={4} 
                value={comment} 
                onChange={(e) => setComment(e.target.value)}
                placeholder={`Add a ${action === 'reject' ? 'reason for rejection' : 'comment'}...`}
              />
            </div>
          ) : null}
          
          {action === 'void' ? (
            <div>
              <label className="block text-sm font-medium text-text-body mb-2">
                Reason <span className="text-red-500">*</span>
              </label>
              <Textarea 
                rows={4} 
                value={voidReason} 
                onChange={(e) => setVoidReason(e.target.value)}
                placeholder="Explain why this invoice is being voided..."
              />
            </div>
          ) : null}

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              <strong>Note:</strong> This action will be processed with a unique idempotency key to prevent duplicate submissions.
            </p>
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-3">
          <Button 
            variant="outline" 
            onClick={() => setAction(null)}
            className="border-border-subtle"
          >
            Cancel
          </Button>
          <Button 
            onClick={() => run.mutate()}
            disabled={run.isPending || (action === 'void' && !voidReason.trim())}
            className={action === 'void' ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}
          >
            {run.isPending ? 'Processing...' : 'Confirm'}
          </Button>
        </div>
      </Modal>
    </div>
  );
}