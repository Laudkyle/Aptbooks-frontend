import IAS12TaxesPage from "./IAS12TaxesPage";

// Alias kept to match router imports.
export default IAS12TaxesPage;
