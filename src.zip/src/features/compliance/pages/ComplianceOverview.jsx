import ComplianceOverviewPage from "./ComplianceOverviewPage";

// Alias kept to match router imports.
export default ComplianceOverviewPage;
