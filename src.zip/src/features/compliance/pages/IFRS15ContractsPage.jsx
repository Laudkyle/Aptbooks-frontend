import IFRS15RevenuePage from "./IFRS15RevenuePage";

// Alias kept to match router imports.
export default IFRS15RevenuePage;
