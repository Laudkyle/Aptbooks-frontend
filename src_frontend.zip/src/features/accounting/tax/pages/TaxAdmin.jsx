import React, { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Bot,
  Globe2,
  DownloadCloud,
  Percent,
  Plus,
  ReceiptText,
  Settings2,
  ShieldCheck,
  WalletCards,
  Calculator,
  AlertTriangle,
  CheckCircle2,
  ClipboardCheck,
  FileText,
  RefreshCw,
} from "lucide-react";

import { useApi } from "../../../../shared/hooks/useApi.js";
import { makeTaxApi } from "../api/tax.api.js";
import { makeCoaApi } from "../../../../features/accounting/chartOfAccounts/api/coa.api.js";
import { PageHeader } from "../../../../shared/components/layout/PageHeader.jsx";
import { ContentCard } from "../../../../shared/components/layout/ContentCard.jsx";
import { Input } from "../../../../shared/components/ui/Input.jsx";
import { Select } from "../../../../shared/components/ui/Select.jsx";
import { AccountSelect } from "../../../../shared/components/forms/AccountSelect.jsx";
import { Button } from "../../../../shared/components/ui/Button.jsx";
import { Badge } from "../../../../shared/components/ui/Badge.jsx";
import { Tabs } from "../../../../shared/components/ui/Tabs.jsx";
import { DataTable } from "../../../../shared/components/data/DataTable.jsx";
import { useToast } from "../../../../shared/components/ui/Toast.jsx";
import { qk } from "../../../../shared/query/keys.js";
import { normalizeRows } from "../../../../shared/tax/frontendTax.js";

function formatLabel(value) {
  return String(value ?? "")
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .replace(/[_-]+/g, " ")
    .replace(/^./, (c) => c.toUpperCase());
}

function statusTone(value) {
  const v = String(value ?? "").toLowerCase();
  if (["posted", "active", "ready", "enabled", "balanced"].includes(v)) return "success";
  if (["draft", "pending", "attention_required"].includes(v)) return "warning";
  if (["voided", "inactive", "disabled", "error"].includes(v)) return "danger";
  return "muted";
}

function moneyCell(value) {
  return value === null || value === undefined || value === "" ? "0.00" : String(value);
}

function cleanCountryPackRow(row) {
  const packCode = row?.packCode || row?.pack_code || row?.code || '';
  return {
    id: row?.id,
    countryCode: row?.countryCode || row?.country_code || '—',
    packCode,
    pack_code: packCode,
    name: row?.name || '—',
    description: row?.description || '',
    version: row?.version || row?.version_no || '—',
    version_no: row?.version_no || row?.version || '—',
    status: row?.status || (row?.isInstalled || row?.is_installed ? 'installed' : 'available'),
    scope: row?.scope || 'Default',
    isInstalled: Boolean(row?.isInstalled || row?.is_installed),
    is_installed: Boolean(row?.isInstalled || row?.is_installed),
    installedAt: row?.installedAt || row?.installed_at || null,
  };
}

export default function TaxAdmin() {
  const { http } = useApi();
  const api = useMemo(() => makeTaxApi(http), [http]);
  const coaApi = useMemo(() => makeCoaApi(http), [http]);
  const qc = useQueryClient();
  const toast = useToast();
  const [tab, setTab] = useState("codes");

  const jurisQ = useQuery({
    queryKey: ["tax-juris"],
    queryFn: api.listJurisdictions,
    staleTime: 10000,
  });

  const codesQ = useQuery({
    queryKey: ["tax-codes-admin"],
    queryFn: () => api.listCodes({}),
    staleTime: 10000,
  });

  const settingsQ = useQuery({
    queryKey: ["tax-settings"],
    queryFn: api.getSettings,
    staleTime: 10000,
  });

  const adjustmentsQ = useQuery({
    queryKey: qk.taxAdjustments({}),
    queryFn: () => api.listAdjustments({}),
    staleTime: 10000,
  });

  const accountsQ = useQuery({
    queryKey: ["coa", "tax-admin"],
    queryFn: () => coaApi.list({ includeArchived: "false" }),
    staleTime: 10000,
  });

  const registrationsQ = useQuery({
    queryKey: ["tax-registrations"],
    queryFn: () => api.listRegistrations({}),
    staleTime: 10000,
  });

  const rulesQ = useQuery({
    queryKey: ["tax-rules"],
    queryFn: () => api.listRules({}),
    staleTime: 10000,
  });

  const profilesQ = useQuery({
    queryKey: ["tax-profiles"],
    queryFn: () => api.listPartnerProfiles({}),
    staleTime: 10000,
  });
  const einvoiceQ = useQuery({
    queryKey: ["tax-einvoice-settings"],
    queryFn: api.getEinvoicingSettings,
    staleTime: 10000,
  });

  const returnTemplatesQ = useQuery({
    queryKey: ["tax-return-templates"],
    queryFn: () => api.listReturnTemplates({}),
    staleTime: 10000,
  });

  const returnConfigsQ = useQuery({
    queryKey: ["tax-return-configs"],
    queryFn: () => api.listReturnConfigs({}),
    staleTime: 10000,
  });

  const countryPacksQ = useQuery({
    queryKey: ["tax-country-packs"],
    queryFn: () => api.listCountryPacks({}),
    staleTime: 10000,
  });

  const automationRulesQ = useQuery({
    queryKey: ["tax-automation-rules"],
    queryFn: () => api.listAutomationRules({}),
    staleTime: 10000,
  });

  const filingAdaptersQ = useQuery({
    queryKey: ["tax-filing-adapters"],
    queryFn: () => api.listFilingAdapters({}),
    staleTime: 10000,
  });

  const ghanaSetupQ = useQuery({
    queryKey: ["tax-ghana-setup"],
    queryFn: api.getGhanaSetupChecklist,
    staleTime: 10000,
  });

  const ghanaDiagnosticsQ = useQuery({
    queryKey: ["tax-ghana-diagnostics"],
    queryFn: api.getGhanaDiagnostics,
    staleTime: 10000,
  });

  const jurisdictions = normalizeRows(jurisQ.data);
  const taxCodes = normalizeRows(codesQ.data);
  const adjustments = normalizeRows(adjustmentsQ.data);
  const accounts = normalizeRows(accountsQ.data);
  const registrations = normalizeRows(registrationsQ.data);
  const rules = normalizeRows(rulesQ.data);
  const profiles = normalizeRows(profilesQ.data);
  const returnTemplates = normalizeRows(returnTemplatesQ.data);
  const returnConfigs = normalizeRows(returnConfigsQ.data);
  const countryPacks = normalizeRows(countryPacksQ.data).map(cleanCountryPackRow);
  const automationRules = normalizeRows(automationRulesQ.data);
  const filingAdapters = normalizeRows(filingAdaptersQ.data);
  const ghanaSetup = ghanaSetupQ.data || {};
  const ghanaDiagnostics = ghanaDiagnosticsQ.data || {};
  const ghanaChecklist = Array.isArray(ghanaSetup.checklist) ? ghanaSetup.checklist : [];
  const ghanaIssues = Array.isArray(ghanaDiagnostics.issues) ? ghanaDiagnostics.issues : [];

  const installCountryPack = useMutation({
    mutationFn: (pack) => api.installCountryPack({ packCode: pack.packCode || pack.pack_code }),
    onSuccess: (res) => {
      const counts = res?.installedCounts || {};
      toast.success(`Country pack installed${counts.taxCodes ? `: ${counts.taxCodes} tax codes` : ''}.`);
      qc.invalidateQueries({ queryKey: ["tax-country-packs"] });
      qc.invalidateQueries({ queryKey: ["tax-juris"] });
      qc.invalidateQueries({ queryKey: ["tax-codes-admin"] });
      qc.invalidateQueries({ queryKey: ["tax-rules"] });
      qc.invalidateQueries({ queryKey: ["tax-return-templates"] });
      qc.invalidateQueries({ queryKey: ["tax-ghana-setup"] });
      qc.invalidateQueries({ queryKey: ["tax-ghana-diagnostics"] });
    },
    onError: (e) => toast.error(e.response?.data?.message ?? e.message ?? "Country pack install failed"),
  });

  const installGhanaWorkflows = useMutation({
    mutationFn: api.installGhanaWorkflows,
    onSuccess: () => {
      toast.success("Ghana tax workflows installed.");
      qc.invalidateQueries({ queryKey: ["tax-country-packs"] });
      qc.invalidateQueries({ queryKey: ["tax-juris"] });
      qc.invalidateQueries({ queryKey: ["tax-codes-admin"] });
      qc.invalidateQueries({ queryKey: ["tax-rules"] });
      qc.invalidateQueries({ queryKey: ["tax-return-templates"] });
      qc.invalidateQueries({ queryKey: ["tax-automation-rules"] });
      qc.invalidateQueries({ queryKey: ["tax-return-configs"] });
      qc.invalidateQueries({ queryKey: ["tax-ghana-setup"] });
      qc.invalidateQueries({ queryKey: ["tax-ghana-diagnostics"] });
    },
    onError: (e) => toast.error(e.response?.data?.message ?? e.message ?? "Ghana workflow install failed"),
  });

  const jurisOptions = [{ value: "", label: "No jurisdiction" }].concat(
    jurisdictions.map((j) => ({ value: j.id, label: `${j.code} — ${j.name}` })),
  );

  const taxCodeOptions = [{ value: "", label: "None" }].concat(
    taxCodes.map((c) => ({ value: c.id, label: `${c.code} — ${c.name}` })),
  );

  const accountLabelById = useMemo(() => {
    const map = new Map();
    accounts.forEach((a) => {
      map.set(
        String(a.id),
        `${a.code ? `${a.code} — ` : ""}${a.name || a.accountName || "Unnamed account"}`,
      );
    });
    return map;
  }, [accounts]);

  const taxCodeLabelById = useMemo(() => {
    const map = new Map();
    taxCodes.forEach((c) => {
      map.set(
        String(c.id),
        `${c.code ? `${c.code} — ` : ""}${c.name || "Unnamed tax code"}`,
      );
    });
    return map;
  }, [taxCodes]);

  const [jCode, setJCode] = useState("");
  const [jName, setJName] = useState("");
  const [countryCode, setCountryCode] = useState("");

  const createJ = useMutation({
    mutationFn: () =>
      api.createJurisdiction({
        code: jCode,
        name: jName,
        countryCode: countryCode || undefined,
      }),
    onSuccess: () => {
      toast.success("Jurisdiction created.");
      setJCode("");
      setJName("");
      setCountryCode("");
      qc.invalidateQueries({ queryKey: ["tax-juris"] });
    },
    onError: (e) =>
      toast.error(e.response?.data?.message ?? e.message ?? "Create failed"),
  });

  const [jurisdictionId, setJurisdictionId] = useState("");
  const [taxType, setTaxType] = useState("VAT");
  const [tCode, setTCode] = useState("");
  const [tName, setTName] = useState("");
  const [rate, setRate] = useState("");
  const [direction, setDirection] = useState("");
  const [taxCategory, setTaxCategory] = useState("standard");

  const createCode = useMutation({
    mutationFn: () =>
      api.createCode({
        jurisdictionId: jurisdictionId || null,
        code: tCode,
        name: tName,
        taxType,
        taxCategory,
        rate,
        direction: direction || null,
      }),
    onSuccess: () => {
      toast.success("Tax code created.");
      setTCode("");
      setTName("");
      setRate("");
      setDirection("");
      qc.invalidateQueries({ queryKey: ["tax-codes-admin"] });
    },
    onError: (e) =>
      toast.error(e.response?.data?.message ?? e.message ?? "Create failed"),
  });

  const [outputTaxAccountId, setOutputTaxAccountId] = useState("");
  const [inputTaxAccountId, setInputTaxAccountId] = useState("");
  const [defaultTaxCodeId, setDefaultTaxCodeId] = useState("");
  const [withholdingTaxPayableAccountId, setWithholdingTaxPayableAccountId] =
    useState("");
  const [
    withholdingTaxReceivableAccountId,
    setWithholdingTaxReceivableAccountId,
  ] = useState("");
  const [nonRecoverableInputTaxAccountId, setNonRecoverableInputTaxAccountId] =
    useState("");
  const [reverseChargeTaxAccountId, setReverseChargeTaxAccountId] =
    useState("");
  const [taxRoundingStrategy, setTaxRoundingStrategy] = useState("line");
  const [enforcePartnerTaxProfile, setEnforcePartnerTaxProfile] =
    useState(false);
  const [requireTaxJurisdiction, setRequireTaxJurisdiction] = useState(false);

  useEffect(() => {
    if (!settingsQ.data?.data) return;
    setOutputTaxAccountId(settingsQ.data?.data.output_tax_account_id ?? "");
    setInputTaxAccountId(settingsQ.data?.data.input_tax_account_id ?? "");
    setDefaultTaxCodeId(settingsQ.data?.data.default_tax_code_id ?? "");
    setWithholdingTaxPayableAccountId(
      settingsQ.data?.data.withholding_tax_payable_account_id  ?? "",
    );
    setWithholdingTaxReceivableAccountId(
      settingsQ.data?.data.withholding_tax_receivable_account_id ?? "",
    );
    setNonRecoverableInputTaxAccountId(
      settingsQ.data?.data.non_recoverable_input_tax_account_id ?? "",
    );
    setReverseChargeTaxAccountId(
      settingsQ.data?.data.reverse_charge_tax_account_id ?? "",
    );
    setTaxRoundingStrategy(settingsQ.data?.data.tax_rounding_strategy ?? "line");
    setEnforcePartnerTaxProfile(
      settingsQ.data?.data.enforce_partner_tax_profile ?? false,
    );
    setRequireTaxJurisdiction(settingsQ.data?.data.require_tax_jurisdiction ?? false);
  }, [settingsQ.data?.data]);

  const saveSettings = useMutation({
    mutationFn: () =>
      api.setSettings({
        outputTaxAccountId: outputTaxAccountId || null,
        inputTaxAccountId: inputTaxAccountId || null,
        defaultTaxCodeId: defaultTaxCodeId || null,
        withholdingTaxPayableAccountId: withholdingTaxPayableAccountId || null,
        withholdingTaxReceivableAccountId:
          withholdingTaxReceivableAccountId || null,
        nonRecoverableInputTaxAccountId:
          nonRecoverableInputTaxAccountId || null,
        reverseChargeTaxAccountId: reverseChargeTaxAccountId || null,
        taxRoundingStrategy,
        enforcePartnerTaxProfile,
        requireTaxJurisdiction,
      }),
    onSuccess: () => {
      toast.success("Settings saved.");
      qc.invalidateQueries({ queryKey: ["tax-settings"] });
    },
    onError: (e) =>
      toast.error(e.response?.data?.message ?? e.message ?? "Save failed"),
  });

  const configuredSettings = useMemo(
    () =>
      [
        {
          label: "Output tax account",
          value: outputTaxAccountId
            ? accountLabelById.get(String(outputTaxAccountId)) ||
              outputTaxAccountId
            : null,
        },
        {
          label: "Input tax account",
          value: inputTaxAccountId
            ? accountLabelById.get(String(inputTaxAccountId)) ||
              inputTaxAccountId
            : null,
        },
        {
          label: "Default tax code",
          value: defaultTaxCodeId
            ? taxCodeLabelById.get(String(defaultTaxCodeId)) || defaultTaxCodeId
            : null,
        },
        {
          label: "Withholding tax payable account",
          value: withholdingTaxPayableAccountId
            ? accountLabelById.get(String(withholdingTaxPayableAccountId)) ||
              withholdingTaxPayableAccountId
            : null,
        },
        {
          label: "Withholding tax receivable account",
          value: withholdingTaxReceivableAccountId
            ? accountLabelById.get(String(withholdingTaxReceivableAccountId)) ||
              withholdingTaxReceivableAccountId
            : null,
        },
        {
          label: "Non-recoverable input tax account",
          value: nonRecoverableInputTaxAccountId
            ? accountLabelById.get(String(nonRecoverableInputTaxAccountId)) ||
              nonRecoverableInputTaxAccountId
            : null,
        },
        {
          label: "Reverse charge tax account",
          value: reverseChargeTaxAccountId
            ? accountLabelById.get(String(reverseChargeTaxAccountId)) ||
              reverseChargeTaxAccountId
            : null,
        },
      ].filter((item) => item.value != null),
    [
      outputTaxAccountId,
      inputTaxAccountId,
      defaultTaxCodeId,
      withholdingTaxPayableAccountId,
      withholdingTaxReceivableAccountId,
      nonRecoverableInputTaxAccountId,
      reverseChargeTaxAccountId,
      accountLabelById,
      taxCodeLabelById,
    ],
  );

  const [reg, setReg] = useState({
    jurisdictionId: "",
    registrationNumber: "",
    legalEntityName: "",
    filingFrequency: "monthly",
    effectiveFrom: "",
    effectiveTo: "",
  });

  const createRegistration = useMutation({
    mutationFn: () => api.createRegistration(reg),
    onSuccess: () => {
      toast.success("Registration created.");
      setReg({
        jurisdictionId: "",
        registrationNumber: "",
        legalEntityName: "",
        filingFrequency: "monthly",
        effectiveFrom: "",
        effectiveTo: "",
      });
      qc.invalidateQueries({ queryKey: ["tax-registrations"] });
    },
    onError: (e) =>
      toast.error(e.response?.data?.message ?? e.message ?? "Create failed"),
  });

  const [rule, setRule] = useState({
    code: "",
    name: "",
    documentType: "invoice",
    supplyType: "goods",
    placeOfSupplyBasis: "customer_location",
    taxCodeId: "",
    priority: 100,
  });

  const createRule = useMutation({
    mutationFn: () => api.createRule(rule),
    onSuccess: () => {
      toast.success("Rule created.");
      setRule({
        code: "",
        name: "",
        documentType: "invoice",
        supplyType: "goods",
        placeOfSupplyBasis: "customer_location",
        taxCodeId: "",
        priority: 100,
      });
      qc.invalidateQueries({ queryKey: ["tax-rules"] });
    },
    onError: (e) =>
      toast.error(e.response?.data?.message ?? e.message ?? "Create failed"),
  });

  const [einvoice, setEinvoice] = useState({
    defaultScheme: "",
    sellerEndpointId: "",
    sellerSchemeId: "",
    transportProfile: "",
    realtimeFilingEnabled: false,
  });

  useEffect(() => {
    if (einvoiceQ.data) setEinvoice((s) => ({ ...s, ...einvoiceQ.data }));
  }, [einvoiceQ.data]);

  const saveEinvoice = useMutation({
    mutationFn: () => api.saveEinvoicingSettings(einvoice),
    onSuccess: () => {
      toast.success("E-invoicing settings saved.");
      qc.invalidateQueries({ queryKey: ["tax-einvoice-settings"] });
    },
    onError: (e) =>
      toast.error(e.response?.data?.message ?? e.message ?? "Save failed"),
  });

  const codeColumns = [
    {
      header: "Code",
      accessorKey: "code",
      render: (row) => (
        <span className="font-medium text-text-strong">{row.code}</span>
      ),
    },
    { header: "Name", accessorKey: "name" },
    {
      header: "Type",
      accessorKey: "tax_type",
      render: (row) => row.tax_type ?? row.taxType ?? "—",
    },
    {
      header: "Category",
      accessorKey: "tax_category",
      render: (row) => (
        <Badge tone="muted">
          {formatLabel(row.tax_category ?? row.taxCategory ?? "standard")}
        </Badge>
      ),
    },
    {
      header: "Direction",
      accessorKey: "direction",
      render: (row) =>
        row.direction ? (
          <Badge tone="muted">{formatLabel(row.direction)}</Badge>
        ) : (
          "—"
        ),
    },
    {
      header: "Rate (%)",
      accessorKey: "rate",
      className: "text-right",
      render: (row) => Number(row.rate ?? 0).toFixed(2),
    },
  ];

  const simpleColumns = (fields) =>
    fields.map((field) => ({
      header: formatLabel(field),
      accessorKey: field,
      render: (row) =>
        /status|state|enabled/i.test(field) ? (
          <Badge tone={statusTone(row[field])}>
            {String(row[field] ?? "—")}
          </Badge>
        ) : (
          String(row[field] ?? "—")
        ),
    }));
    const adColumns = (fields) =>
    fields.map((field) => {
        // If field is a string, use it for both header and accessor
        // If field is an object, use header and accessor separately
        const header = typeof field === 'string' ? formatLabel(field) : field.header;
        const accessorKey = typeof field === 'string' ? field : field.accessorKey;
        const customRender = typeof field === 'string' ? null : field.render;

        return {
            header,
            accessorKey,
            render: (row) => {
                // Use custom render if provided
                if (customRender) {
                    return customRender(row);
                }
                
                // Default rendering logic
                if (/status|state|enabled/i.test(accessorKey)) {
                    return (
                        <Badge tone={statusTone(row[accessorKey])}>
                            {String(row[accessorKey] ?? "—")}
                        </Badge>
                    );
                }
                return String(row[accessorKey] ?? "—");
            },
        };
    });

  const [ghanaCalc, setGhanaCalc] = useState({ taxCode: "GH_VAT_EFFECTIVE_20", baseAmount: "1000.00", calculationMode: "exclusive" });
  const [ghanaCalcResult, setGhanaCalcResult] = useState(null);
  const calculateGhana = useMutation({
    mutationFn: () => api.calculateGhanaTax(ghanaCalc),
    onSuccess: (data) => setGhanaCalcResult(data),
    onError: (e) => toast.error(e.response?.data?.message ?? e.message ?? "Tax calculation failed"),
  });

  const [reportRange, setReportRange] = useState({ from: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0,10), to: new Date().toISOString().slice(0,10) });
  const vatSummaryQ = useQuery({
    queryKey: ["tax-vat-summary", reportRange],
    queryFn: () => api.getVatSummary(reportRange),
    enabled: tab === "ghana" && !!reportRange.from && !!reportRange.to,
  });
  const whtSummaryQ = useQuery({
    queryKey: ["tax-wht-summary", reportRange],
    queryFn: () => api.getWithholdingSummary(reportRange),
    enabled: ["ghana", "reports"].includes(tab) && !!reportRange.from && !!reportRange.to,
  });

  const ghanaVatReturnQ = useQuery({
    queryKey: ["tax-ghana-vat-return", reportRange],
    queryFn: () => api.getGhanaVatReturn(reportRange),
    enabled: tab === "reports" && !!reportRange.from && !!reportRange.to,
  });

  const ghanaVatTxQ = useQuery({
    queryKey: ["tax-ghana-vat-transactions", reportRange],
    queryFn: () => api.getGhanaVatTransactions(reportRange),
    enabled: tab === "reports" && !!reportRange.from && !!reportRange.to,
  });

  const taxReconQ = useQuery({
    queryKey: ["tax-reconciliation-report", reportRange],
    queryFn: () => api.getGhanaVatReconciliation(reportRange),
    enabled: tab === "reports" && !!reportRange.from && !!reportRange.to,
  });

  const whtPayableQ = useQuery({
    queryKey: ["tax-wht-payable", reportRange],
    queryFn: () => api.getWithholdingPayable(reportRange),
    enabled: tab === "reports" && !!reportRange.from && !!reportRange.to,
  });

  const whtReceivableQ = useQuery({
    queryKey: ["tax-wht-receivable", reportRange],
    queryFn: () => api.getWithholdingReceivable(reportRange),
    enabled: tab === "reports" && !!reportRange.from && !!reportRange.to,
  });

  const taxDiagnosticsReportQ = useQuery({
    queryKey: ["tax-diagnostics-report", reportRange],
    queryFn: () => api.getTaxDiagnosticsReport(reportRange),
    enabled: tab === "reports" && !!reportRange.from && !!reportRange.to,
  });

  const createVatReturn = useMutation({
    mutationFn: () => api.createVatReturn({ ...reportRange, includeGhanaComponents: true }),
    onSuccess: (data) => toast.success(`Draft VAT return created${data?.return_id ? `: ${data.return_id}` : ""}.`),
    onError: (e) => toast.error(e.response?.data?.message ?? e.message ?? "VAT return creation failed"),
  });

  return (
    <div className="space-y-6 pb-8">
      <PageHeader
        title="Tax administration"
        subtitle="Wave 1–3 frontend coverage for tax domain redesign, determination controls, partner tax profiles, e-invoicing, filing adapters, automation, and country packs."
        icon={ShieldCheck}
      />

      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { value: "codes", label: "Codes", icon: Percent },
          { value: "registrations", label: "Registrations", icon: Globe2 },
          { value: "rules", label: "Rules", icon: WalletCards },
          { value: "settings", label: "Settings", icon: Settings2 },
          { value: "profiles", label: "Partner profiles", icon: ShieldCheck },
          {
            value: "compliance",
            label: "E-invoicing & returns",
            icon: ReceiptText,
          },
          { value: "automation", label: "Automation & packs", icon: Bot },
          { value: "reports", label: "Tax reports", icon: FileText },
          { value: "ghana", label: "Ghana tax workflows", icon: ClipboardCheck },
        ]}
      />

      {tab === "codes" ? (
        <div className="space-y-6">
          <ContentCard title="New jurisdiction">
            <div className="grid gap-4 md:grid-cols-4">
              <Input
                label="Code"
                value={jCode}
                onChange={(e) => setJCode(e.target.value)}
              />
              <Input
                label="Name"
                value={jName}
                onChange={(e) => setJName(e.target.value)}
              />
              <Input
                label="Country code"
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value.toUpperCase())}
              />
              <div className="flex items-end">
                <Button
                  leftIcon={Plus}
                  onClick={() => createJ.mutate()}
                  disabled={!jCode || !jName}
                >
                  Create jurisdiction
                </Button>
              </div>
            </div>
          </ContentCard>

          <ContentCard title="New tax code">
            <div className="grid gap-4 md:grid-cols-3">
              <Select
                label="Jurisdiction"
                value={jurisdictionId}
                onChange={(e) => setJurisdictionId(e.target.value)}
                options={jurisOptions}
              />
              <Select
                label="Type"
                value={taxType}
                onChange={(e) => setTaxType(e.target.value)}
                options={[
                  { value: "VAT", label: "VAT" },
                  { value: "GST", label: "GST" },
                  { value: "SALES", label: "Sales tax" },
                  { value: "WHT", label: "Withholding" },
                ]}
              />
              <Select
                label="Direction"
                value={direction}
                onChange={(e) => setDirection(e.target.value)}
                options={[
                  { value: "", label: "(optional)" },
                  { value: "output", label: "Output" },
                  { value: "input", label: "Input" },
                ]}
              />
              <Select
                label="Category"
                value={taxCategory}
                onChange={(e) => setTaxCategory(e.target.value)}
                options={[
                  { value: "standard", label: "Standard" },
                  { value: "zero_rated", label: "Zero rated" },
                  { value: "exempt", label: "Exempt" },
                  { value: "reverse_charge", label: "Reverse charge" },
                  { value: "withholding", label: "Withholding" },
                ]}
              />
              <Input
                label="Code"
                value={tCode}
                onChange={(e) => setTCode(e.target.value)}
              />
              <Input
                label="Name"
                value={tName}
                onChange={(e) => setTName(e.target.value)}
              />
              <Input
                label="Rate (%)"
                type="number"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
              />
              <div className="md:col-span-3 flex justify-end">
                <Button
                  leftIcon={Plus}
                  onClick={() => createCode.mutate()}
                  disabled={!tCode || !tName || rate === ""}
                >
                  Create tax code
                </Button>
              </div>
            </div>
          </ContentCard>

          <ContentCard title="Tax codes register">
            <DataTable columns={codeColumns} rows={taxCodes} />
          </ContentCard>

          <ContentCard title="Jurisdictions">
            <DataTable
              columns={simpleColumns(["code", "name", "country_code"])}
              rows={jurisdictions}
            />
          </ContentCard>
        </div>
      ) : null}

      {tab === "registrations" ? (
        <div className="space-y-6">
          <ContentCard title="New tax registration">
            <div className="grid gap-4 md:grid-cols-3">
              <Select
                label="Jurisdiction"
                value={reg.jurisdictionId}
                onChange={(e) =>
                  setReg((s) => ({ ...s, jurisdictionId: e.target.value }))
                }
                options={jurisOptions}
              />
              <Input
                label="Registration number"
                value={reg.registrationNumber}
                onChange={(e) =>
                  setReg((s) => ({ ...s, registrationNumber: e.target.value }))
                }
              />
              <Input
                label="Legal entity"
                value={reg.legalEntityName}
                onChange={(e) =>
                  setReg((s) => ({ ...s, legalEntityName: e.target.value }))
                }
              />
              <Select
                label="Filing frequency"
                value={reg.filingFrequency}
                onChange={(e) =>
                  setReg((s) => ({ ...s, filingFrequency: e.target.value }))
                }
                options={[
                  { value: "monthly", label: "Monthly" },
                  { value: "quarterly", label: "Quarterly" },
                  { value: "annual", label: "Annual" },
                ]}
              />
              <Input
                label="Effective from"
                type="date"
                value={reg.effectiveFrom}
                onChange={(e) =>
                  setReg((s) => ({ ...s, effectiveFrom: e.target.value }))
                }
              />
              <Input
                label="Effective to"
                type="date"
                value={reg.effectiveTo}
                onChange={(e) =>
                  setReg((s) => ({ ...s, effectiveTo: e.target.value }))
                }
              />
              <div className="md:col-span-3 flex justify-end">
                <Button
                  leftIcon={Plus}
                  onClick={() => createRegistration.mutate()}
                  disabled={!reg.registrationNumber}
                >
                  Create registration
                </Button>
              </div>
            </div>
          </ContentCard>

          <ContentCard title="Registrations">
            <DataTable
              columns={adColumns([
                {header:"Registration Number", accessorKey:"registration_no"},
                {header:"Legal Entity Name", accessorKey:"legal_entity_name"},
                {header:"Filing Frequency", accessorKey:"filing_frequency"},
                {header:"Effective From", accessorKey:"effective_from"},
                {header:"Effective To", accessorKey:"effective_to"},
                {header:"Registration Type", accessorKey:"registration_type"},
              ])}
              rows={registrations}
            />
          </ContentCard>
        </div>
      ) : null}

      {tab === "rules" ? (
        <div className="space-y-6">
          <ContentCard title="New determination rule">
            <div className="grid gap-4 md:grid-cols-3">
              <Input
                label="Code"
                value={rule.code}
                onChange={(e) =>
                  setRule((s) => ({ ...s, code: e.target.value }))
                }
              />
              <Input
                label="Name"
                value={rule.name}
                onChange={(e) =>
                  setRule((s) => ({ ...s, name: e.target.value }))
                }
              />
              <Select
                label="Document type"
                value={rule.documentType}
                onChange={(e) =>
                  setRule((s) => ({ ...s, documentType: e.target.value }))
                }
                options={[
                  { value: "invoice", label: "Invoice" },
                  { value: "bill", label: "Bill" },
                  { value: "credit_note", label: "Credit note" },
                  { value: "debit_note", label: "Debit note" },
                ]}
              />
              <Select
                label="Supply type"
                value={rule.supplyType}
                onChange={(e) =>
                  setRule((s) => ({ ...s, supplyType: e.target.value }))
                }
                options={[
                  { value: "goods", label: "Goods" },
                  { value: "services", label: "Services" },
                  { value: "mixed", label: "Mixed" },
                  { value: "import", label: "Import" },
                  { value: "export", label: "Export" },
                ]}
              />
              <Select
                label="Place of supply basis"
                value={rule.placeOfSupplyBasis}
                onChange={(e) =>
                  setRule((s) => ({ ...s, placeOfSupplyBasis: e.target.value }))
                }
                options={[
                  { value: "customer_location", label: "Customer location" },
                  { value: "supplier_location", label: "Supplier location" },
                  { value: "ship_to", label: "Ship-to" },
                  {
                    value: "service_performance",
                    label: "Service performance",
                  },
                ]}
              />
              <Select
                label="Tax code"
                value={rule.taxCodeId}
                onChange={(e) =>
                  setRule((s) => ({ ...s, taxCodeId: e.target.value }))
                }
                options={taxCodeOptions}
              />
              <Input
                label="Priority"
                type="number"
                value={rule.priority}
                onChange={(e) =>
                  setRule((s) => ({ ...s, priority: Number(e.target.value) }))
                }
              />
              <div className="md:col-span-3 flex justify-end">
                <Button
                  leftIcon={Plus}
                  onClick={() => createRule.mutate()}
                  disabled={!rule.code || !rule.name}
                >
                  Create rule
                </Button>
              </div>
            </div>
          </ContentCard>

          <ContentCard title="Determination rules">
            <DataTable
              columns={adColumns([
                { header: "Name", accessorKey: "name" },
                { header: "Document Type", accessorKey: "document_type" },
                { header: "Supply Type", accessorKey: "partner_type" },
                { header: "Place of Supply Basis", accessorKey: "place_of_supply_basis" },
                { header: "Tax Code", accessorKey: "tax_code_code" },
                { header: "Priority", accessorKey: "priority" },
                { header: "Status", accessorKey: "status" },
              ])}
              rows={rules}
            />
          </ContentCard>
        </div>
      ) : null}

      {tab === "settings" ? (
        <ContentCard title="Posting and control settings">
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            <AccountSelect
              label="Output tax account"
              value={outputTaxAccountId}
              onChange={(e) => setOutputTaxAccountId(e.target.value)}
              allowEmpty
            />
            <AccountSelect
              label="Input tax account"
              value={inputTaxAccountId}
              onChange={(e) => setInputTaxAccountId(e.target.value)}
              allowEmpty
            />
            <Select
              label="Default tax code"
              value={defaultTaxCodeId}
              onChange={(e) => setDefaultTaxCodeId(e.target.value)}
              options={taxCodeOptions}
            />
            <AccountSelect
              label="Withholding tax payable account"
              value={withholdingTaxPayableAccountId}
              onChange={(e) =>
                setWithholdingTaxPayableAccountId(e.target.value)
              }
              allowEmpty
            />
            <AccountSelect
              label="Withholding tax receivable account"
              value={withholdingTaxReceivableAccountId}
              onChange={(e) =>
                setWithholdingTaxReceivableAccountId(e.target.value)
              }
              allowEmpty
            />
            <AccountSelect
              label="Non-recoverable input tax account"
              value={nonRecoverableInputTaxAccountId}
              onChange={(e) =>
                setNonRecoverableInputTaxAccountId(e.target.value)
              }
              allowEmpty
            />
            <AccountSelect
              label="Reverse charge tax account"
              value={reverseChargeTaxAccountId}
              onChange={(e) => setReverseChargeTaxAccountId(e.target.value)}
              allowEmpty
            />
            <Select
              label="Tax rounding strategy"
              value={taxRoundingStrategy}
              onChange={(e) => setTaxRoundingStrategy(e.target.value)}
              options={[
                { value: "line", label: "Line (round per line item)" },
                { value: "total", label: "Total (round on total amount)" },
              ]}
            />
            <div className="flex flex-col gap-3">
              <label className="flex items-center gap-2 rounded-xl border border-border-subtle px-3 py-2 text-sm">
                <input
                  type="checkbox"
                  checked={enforcePartnerTaxProfile}
                  onChange={(e) =>
                    setEnforcePartnerTaxProfile(e.target.checked)
                  }
                />
                Enforce partner tax profile
              </label>
              <label className="flex items-center gap-2 rounded-xl border border-border-subtle px-3 py-2 text-sm">
                <input
                  type="checkbox"
                  checked={requireTaxJurisdiction}
                  onChange={(e) => setRequireTaxJurisdiction(e.target.checked)}
                />
                Require tax jurisdiction
              </label>
            </div>
            <div className="flex items-end">
              <Button
                onClick={() => saveSettings.mutate()}
                loading={saveSettings.isPending}
              >
                Save settings
              </Button>
            </div>
          </div>

          {configuredSettings.length ? (
            <div className="mt-6 rounded-2xl border border-border-subtle bg-surface/60 p-4">
              <div className="mb-3 text-sm font-semibold text-text-strong">
                Current account mappings
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                {configuredSettings.map((item) => (
                  <div
                    key={item.label}
                    className="rounded-xl border border-border-subtle bg-background px-3 py-2"
                  >
                    <div className="text-xs uppercase tracking-wide text-text-muted">
                      {item.label}
                    </div>
                    <div className="mt-1 text-sm font-medium text-text-strong">
                      {item.value}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : null}
        </ContentCard>
      ) : null}

      {tab === "profiles" ? (
        <ContentCard title="Partner tax profiles">
          <DataTable
            columns={
              adColumns([
              { header:"Legal name",accessorKey:"legal_name" },
              { header:"Tax class",accessorKey:"tax_class" },
              { header:"Registration status",accessorKey:"registration_status" },
              {header:"WithHolding Rate",accessorKey:"withholding_rate_override"},
              {header:"recoverability Percent",accessorKey:"recoverable_percent_override"},
              {header:"Destination Country Code",accessorKey:"destination_country_code"},
            ])
          }
            rows={profiles}
          />
        </ContentCard>
      ) : null}

      {tab === "compliance" ? (
        <div className="space-y-6">
          <ContentCard title="E-invoicing settings">
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              <Input
                label="Default scheme"
                value={einvoice.defaultScheme ?? ""}
                onChange={(e) =>
                  setEinvoice((s) => ({ ...s, defaultScheme: e.target.value }))
                }
              />
              <Input
                label="Seller endpoint ID"
                value={einvoice.sellerEndpointId ?? ""}
                onChange={(e) =>
                  setEinvoice((s) => ({
                    ...s,
                    sellerEndpointId: e.target.value,
                  }))
                }
              />
              <Input
                label="Seller scheme ID"
                value={einvoice.sellerSchemeId ?? ""}
                onChange={(e) =>
                  setEinvoice((s) => ({ ...s, sellerSchemeId: e.target.value }))
                }
              />
              <Input
                label="Transport profile"
                value={einvoice.transportProfile ?? ""}
                onChange={(e) =>
                  setEinvoice((s) => ({
                    ...s,
                    transportProfile: e.target.value,
                  }))
                }
              />
              <label className="flex items-center gap-2 rounded-xl border border-border-subtle px-3 py-2 text-sm">
                <input
                  type="checkbox"
                  checked={!!einvoice.realtimeFilingEnabled}
                  onChange={(e) =>
                    setEinvoice((s) => ({
                      ...s,
                      realtimeFilingEnabled: e.target.checked,
                    }))
                  }
                />
                Enable real-time filing
              </label>
              <div className="flex items-end">
                <Button
                  onClick={() => saveEinvoice.mutate()}
                  loading={saveEinvoice.isPending}
                >
                  Save e-invoicing
                </Button>
              </div>
            </div>
          </ContentCard>

          <ContentCard title="Return templates">
            <DataTable
              columns={simpleColumns([
                "templateCode",
                "name",
                "jurisdictionCode",
                "taxType",
                "status",
              ])}
              rows={returnTemplates}
            />
          </ContentCard>

          <ContentCard title="Jurisdiction return configs">
            <DataTable
              columns={simpleColumns([
                "jurisdictionCode",
                "filingFrequency",
                "basis",
                "status",
              ])}
              rows={returnConfigs}
            />
          </ContentCard>

          <ContentCard title="Manual tax adjustments">
            <DataTable
              columns={simpleColumns([
                "reference",
                "direction",
                "taxAmount",
                "status",
              ])}
              rows={adjustments}
            />
          </ContentCard>
        </div>
      ) : null}

      {tab === "reports" ? (
        <div className="space-y-6">
          <ContentCard
            title="Tax reports workspace"
            subtitle="Run filing-ready tax previews, reconcile tax to the ledger, and drill down to source transactions. Preview reports do not create tax returns; use Create draft VAT return when you intentionally want to save one."
            actions={
              <Button size="sm" leftIcon={DownloadCloud} loading={createVatReturn.isPending} onClick={() => createVatReturn.mutate()} disabled={!reportRange.from || !reportRange.to}>
                Create draft VAT return
              </Button>
            }
          >
            <div className="grid gap-4 md:grid-cols-3">
              <Input label="From" type="date" value={reportRange.from} onChange={(e) => setReportRange((st) => ({ ...st, from: e.target.value }))} />
              <Input label="To" type="date" value={reportRange.to} onChange={(e) => setReportRange((st) => ({ ...st, to: e.target.value }))} />
              <div className="flex items-end">
                <Button variant="secondary" leftIcon={RefreshCw} onClick={() => { ghanaVatReturnQ.refetch(); ghanaVatTxQ.refetch(); taxReconQ.refetch(); whtPayableQ.refetch(); whtReceivableQ.refetch(); taxDiagnosticsReportQ.refetch(); }}>Refresh reports</Button>
              </div>
            </div>
          </ContentCard>

          <ContentCard title="Ghana VAT / NHIL / GETFund return preview" subtitle="Box-level preview with taxable amount, tax amount, and transaction counts.">
            <div className="mb-4 grid gap-3 md:grid-cols-4">
              <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Output tax</div><div className="text-lg font-semibold">{ghanaVatReturnQ.data?.totals?.output_tax ?? "0.00"}</div></div>
              <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Input tax</div><div className="text-lg font-semibold">{ghanaVatReturnQ.data?.totals?.input_tax ?? "0.00"}</div></div>
              <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Net payable</div><div className="text-lg font-semibold">{ghanaVatReturnQ.data?.totals?.net_tax_payable ?? "0.00"}</div></div>
              <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Transactions</div><div className="text-lg font-semibold">{ghanaVatReturnQ.data?.coverage?.transaction_count ?? 0}</div></div>
            </div>
            <DataTable
              columns={[
                { header: "Box", accessorKey: "box_code" },
                { header: "Label", accessorKey: "label" },
                { header: "Direction", accessorKey: "direction" },
                { header: "Taxable", accessorKey: "taxable_amount", render: (row) => moneyCell(row.taxable_amount) },
                { header: "Tax", accessorKey: "tax_amount", render: (row) => moneyCell(row.tax_amount) },
                { header: "Count", accessorKey: "transaction_count" },
              ]}
              rows={ghanaVatReturnQ.data?.boxes || []}
              emptyMessage="No VAT return lines for the selected period."
            />
          </ContentCard>

          <ContentCard title="VAT transaction drill-down">
            <DataTable
              columns={[
                { header: "Date", accessorKey: "document_date" },
                { header: "Document", accessorKey: "document_no" },
                { header: "Partner", accessorKey: "partner_name" },
                { header: "Tax code", accessorKey: "tax_code" },
                { header: "Box", accessorKey: "box_code" },
                { header: "Direction", accessorKey: "direction" },
                { header: "Taxable", accessorKey: "signed_taxable_amount", render: (row) => moneyCell(row.signed_taxable_amount) },
                { header: "Tax", accessorKey: "signed_tax_amount", render: (row) => moneyCell(row.signed_tax_amount) },
              ]}
              rows={ghanaVatTxQ.data || []}
              emptyMessage="No Ghana VAT/NHIL/GETFund transactions for this period."
            />
          </ContentCard>

          <ContentCard title="Tax reconciliation" subtitle="Shows both VAT payable basis and GL debit-minus-credit basis to avoid sign confusion.">
            <div className="mb-4 grid gap-3 md:grid-cols-4">
              <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Status</div><Badge tone={statusTone(taxReconQ.data?.status)}>{taxReconQ.data?.status || "not run"}</Badge></div>
              <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">VAT payable basis</div><div className="text-lg font-semibold">{taxReconQ.data?.sourceTotals?.vatPayableBasis ?? "0.00"}</div></div>
              <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Expected GL balance</div><div className="text-lg font-semibold">{taxReconQ.data?.sourceTotals?.expectedGlBalanceDebitMinusCredit ?? "0.00"}</div></div>
              <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Difference</div><div className="text-lg font-semibold">{taxReconQ.data?.difference ?? "0.00"}</div></div>
            </div>
            <DataTable
              columns={[
                { header: "Account", accessorKey: "account_name" },
                { header: "Code", accessorKey: "account_code" },
                { header: "Debit", accessorKey: "debit_total", render: (row) => moneyCell(row.debit_total) },
                { header: "Credit", accessorKey: "credit_total", render: (row) => moneyCell(row.credit_total) },
                { header: "Net", accessorKey: "net_amount", render: (row) => moneyCell(row.net_amount) },
              ]}
              rows={taxReconQ.data?.glTotals?.accounts || []}
              emptyMessage="No mapped tax GL activity found for the selected period."
            />
          </ContentCard>

          <div className="grid gap-6 xl:grid-cols-2">
            <ContentCard title="Withholding payable">
              <div className="mb-3 grid gap-3 md:grid-cols-3">
                <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Total taxable</div><div className="text-lg font-semibold">{whtPayableQ.data?.totalTaxable ?? "0.00"}</div></div>
                <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Total WHT</div><div className="text-lg font-semibold">{whtPayableQ.data?.totalTax ?? "0.00"}</div></div>
                <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Items</div><div className="text-lg font-semibold">{whtPayableQ.data?.count ?? 0}</div></div>
              </div>
              <DataTable columns={[{ header: "Tax code", accessorKey: "tax_code" }, { header: "Name", accessorKey: "tax_code_name" }, { header: "Taxable", accessorKey: "taxable_amount" }, { header: "Tax", accessorKey: "tax_amount" }, { header: "Count", accessorKey: "count" }]} rows={whtPayableQ.data?.byTaxCode || []} />
            </ContentCard>

            <ContentCard title="Withholding receivable">
              <div className="mb-3 grid gap-3 md:grid-cols-3">
                <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Total taxable</div><div className="text-lg font-semibold">{whtReceivableQ.data?.totalTaxable ?? "0.00"}</div></div>
                <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Total WHT</div><div className="text-lg font-semibold">{whtReceivableQ.data?.totalTax ?? "0.00"}</div></div>
                <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Items</div><div className="text-lg font-semibold">{whtReceivableQ.data?.count ?? 0}</div></div>
              </div>
              <DataTable columns={[{ header: "Tax code", accessorKey: "tax_code" }, { header: "Name", accessorKey: "tax_code_name" }, { header: "Taxable", accessorKey: "taxable_amount" }, { header: "Tax", accessorKey: "tax_amount" }, { header: "Count", accessorKey: "count" }]} rows={whtReceivableQ.data?.byTaxCode || []} />
            </ContentCard>
          </div>

          <ContentCard title="Tax diagnostics for selected period">
            <DataTable
              columns={[
                { header: "Issue", accessorKey: "issue_code" },
                { header: "Date", accessorKey: "document_date" },
                { header: "Document", accessorKey: "document_no" },
                { header: "Line", accessorKey: "line_no" },
                { header: "Description", accessorKey: "description" },
              ]}
              rows={taxDiagnosticsReportQ.data || []}
              emptyMessage="No reporting diagnostics for the selected period."
            />
          </ContentCard>
        </div>
      ) : null}

      {tab === "ghana" ? (
        <div className="space-y-6">
          <ContentCard
            title="Ghana tax setup assistant"
            subtitle="Use this screen after installing the Ghana country pack to confirm readiness, run quick calculations, and review VAT/WHT summaries."
            actions={
              <Button
                size="sm"
                leftIcon={DownloadCloud}
                loading={installGhanaWorkflows.isPending}
                onClick={() => installGhanaWorkflows.mutate()}
              >
                Install Ghana workflows
              </Button>
            }
          >
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {ghanaChecklist.map((item) => (
                <div key={item.key} className="rounded-2xl border border-border-subtle bg-background p-4">
                  <div className="flex items-start gap-3">
                    {item.complete ? <CheckCircle2 className="mt-0.5 h-5 w-5 text-green-600" /> : <AlertTriangle className="mt-0.5 h-5 w-5 text-amber-600" />}
                    <div>
                      <div className="font-medium text-text-strong">{item.label}</div>
                      <div className="mt-1 text-xs text-text-muted">{item.complete ? "Complete" : item.action}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ContentCard>

          <ContentCard title="Ghana tax diagnostics">
            {ghanaIssues.length ? (
              <DataTable
                columns={[
                  { header: "Severity", accessorKey: "severity", render: (row) => <Badge tone={row.severity === "warning" ? "warning" : row.severity === "error" ? "danger" : "muted"}>{row.severity}</Badge> },
                  { header: "Issue", accessorKey: "message" },
                  { header: "Recommendation", accessorKey: "recommendation" },
                ]}
                rows={ghanaIssues}
              />
            ) : (
              <div className="rounded-2xl border border-border-subtle bg-background p-4 text-sm text-text-muted">No Ghana tax setup warnings detected.</div>
            )}
          </ContentCard>

          <ContentCard title="Ghana tax calculator">
            <div className="grid gap-4 md:grid-cols-4">
              <Select
                label="Tax code"
                value={ghanaCalc.taxCode}
                onChange={(e) => setGhanaCalc((s) => ({ ...s, taxCode: e.target.value }))}
                options={taxCodes.filter((c) => String(c.code || "").startsWith("GH_")).map((c) => ({ value: c.code, label: `${c.code} — ${c.name}` }))}
              />
              <Input
                label="Base/entered amount"
                value={ghanaCalc.baseAmount}
                onChange={(e) => setGhanaCalc((s) => ({ ...s, baseAmount: e.target.value }))}
              />
              <Select
                label="Calculation mode"
                value={ghanaCalc.calculationMode}
                onChange={(e) => setGhanaCalc((s) => ({ ...s, calculationMode: e.target.value }))}
                options={[
                  { value: "exclusive", label: "Tax exclusive" },
                  { value: "inclusive", label: "Tax inclusive" },
                ]}
              />
              <div className="flex items-end">
                <Button leftIcon={Calculator} loading={calculateGhana.isPending} onClick={() => calculateGhana.mutate()} disabled={!ghanaCalc.taxCode || !ghanaCalc.baseAmount}>Calculate</Button>
              </div>
            </div>
            {ghanaCalcResult ? (
              <div className="mt-4 grid gap-3 md:grid-cols-3">
                <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Taxable base</div><div className="text-lg font-semibold">GHS {ghanaCalcResult.baseAmount}</div></div>
                <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Tax amount</div><div className="text-lg font-semibold">GHS {ghanaCalcResult.taxAmount}</div></div>
                <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Gross amount</div><div className="text-lg font-semibold">GHS {ghanaCalcResult.grossAmount}</div></div>
              </div>
            ) : null}
          </ContentCard>

          <ContentCard title="VAT and withholding summary">
            <div className="mb-4 grid gap-4 md:grid-cols-3">
              <Input label="From" type="date" value={reportRange.from} onChange={(e) => setReportRange((s) => ({ ...s, from: e.target.value }))} />
              <Input label="To" type="date" value={reportRange.to} onChange={(e) => setReportRange((s) => ({ ...s, to: e.target.value }))} />
            </div>
            <div className="grid gap-3 md:grid-cols-4">
              <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Output VAT</div><div className="text-lg font-semibold">{vatSummaryQ.data?.outputTax ?? "0.00"}</div></div>
              <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Input VAT</div><div className="text-lg font-semibold">{vatSummaryQ.data?.inputTax ?? "0.00"}</div></div>
              <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">Net VAT payable</div><div className="text-lg font-semibold">{vatSummaryQ.data?.netTaxPayable ?? "0.00"}</div></div>
              <div className="rounded-xl border border-border-subtle bg-background p-3"><div className="text-xs text-text-muted">WHT payable/receivable</div><div className="text-lg font-semibold">{whtSummaryQ.data?.totalTax ?? "0.00"}</div></div>
            </div>
          </ContentCard>
        </div>
      ) : null}

      {tab === "automation" ? (
        <div className="space-y-6">
          <ContentCard title="Automation rules">
            <DataTable
              columns={simpleColumns(["code", "name", "triggerType", "status"])}
              rows={automationRules}
            />
          </ContentCard>

          <ContentCard title="Near-real-time filing adapters">
            <DataTable
              columns={simpleColumns([
                "adapterCode",
                "name",
                "jurisdictionCode",
                "status",
              ])}
              rows={filingAdapters}
            />
          </ContentCard>

          <ContentCard
            title="Country packs"
            actions={
              <Button
                size="sm"
                leftIcon={DownloadCloud}
                loading={installCountryPack.isPending}
                onClick={() => {
                  const gh = countryPacks.find((p) => String(p.pack_code || p.packCode || '').includes('GH-TAX-2026-COMPLETE'))
                    || countryPacks.find((p) => String(p.country_code || p.countryCode || '').toUpperCase() === 'GH');
                  if (!gh) return toast.error('Ghana country pack is not available. Run backend migrations first.');
                  installCountryPack.mutate(gh);
                }}
              >
                Install Ghana defaults
              </Button>
            }
          >
            <DataTable
              columns={[
                { header: 'Country', accessorKey: 'countryCode', render: (row) => row.countryCode || row.country_code || '—' },
                { header: 'Pack', accessorKey: 'pack_code', render: (row) => row.pack_code || row.packCode || '—' },
                { header: 'Name', accessorKey: 'name', render: (row) => row.name || '—' },
                { header: 'Version', accessorKey: 'version_no', render: (row) => row.version_no || row.version || '—' },
                { header: 'Scope', accessorKey: 'scope', render: (row) => row.scope || 'Default' },
                { header: 'Status', accessorKey: 'status', render: (row) => <Badge tone={statusTone(row.status)}>{String(row.status ?? '—')}</Badge> },
                {
                  header: 'Action',
                  accessorKey: 'action',
                  render: (row) => (
                    <Button
                      size="sm"
                      variant={row.is_installed || row.isInstalled ? 'outline' : 'primary'}
                      leftIcon={DownloadCloud}
                      loading={installCountryPack.isPending}
                      onClick={(event) => {
                        event.stopPropagation();
                        installCountryPack.mutate(row);
                      }}
                    >
                      {row.is_installed || row.isInstalled ? 'Reinstall' : 'Install'}
                    </Button>
                  ),
                },
              ]}
              rows={countryPacks}
            />
          </ContentCard>
        </div>
      ) : null}
    </div>
  );
}