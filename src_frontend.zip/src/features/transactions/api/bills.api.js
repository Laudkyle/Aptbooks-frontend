import { endpoints } from '../../../shared/api/endpoints.js';
import { ensureIdempotencyKey } from '../../../shared/api/idempotency.js';

export function makeBillsApi(http) {
  return {
    list: async (qs) => (await http.get(endpoints.modules.transactions.bills.list(qs))).data,
    create: async (body, { idempotencyKey } = {}) =>
      (await http.post(endpoints.modules.transactions.bills.create, body, { headers: ensureIdempotencyKey(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {}) })).data,
    get: async (id) => (await http.get(endpoints.modules.transactions.bills.detail(id))).data,
    determineTaxes: async (body, { id = 'preview', idempotencyKey } = {}) =>
      (await http.post(endpoints.modules.transactions.bills.determineTaxes(id), body, { headers: ensureIdempotencyKey(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {}) })).data,
    getEinvoicePreview: async (id) => (await http.get(endpoints.modules.transactions.bills.einvoicePreview(id))).data,
    getFilingStatus: async (id) => (await http.get(endpoints.modules.transactions.bills.filingStatus(id))).data,

    submitForApproval: async (id, { idempotencyKey } = {}) =>
      (await http.post(endpoints.modules.transactions.bills.submitForApproval(id), null, { headers: ensureIdempotencyKey(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {}) })).data,
    approve: async (id, body = {}, { idempotencyKey } = {}) =>
      (await http.post(endpoints.modules.transactions.bills.approve(id), body, { headers: ensureIdempotencyKey(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {}) })).data,
    reject: async (id, body = {}, { idempotencyKey } = {}) =>
      (await http.post(endpoints.modules.transactions.bills.reject(id), body, { headers: ensureIdempotencyKey(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {}) })).data,
    issue: async (id, { idempotencyKey } = {}) =>
      (await http.post(endpoints.modules.transactions.bills.issue(id), null, { headers: ensureIdempotencyKey(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {}) })).data,
    void: async (id, body, { idempotencyKey } = {}) =>
      (await http.post(endpoints.modules.transactions.bills.void(id), body, { headers: ensureIdempotencyKey(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {}) })).data
  };
}
