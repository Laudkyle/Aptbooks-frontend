// Backwards-compatible alias (some nav items referenced StatementsPage)
export { default } from './BankStatementsPage.jsx';
