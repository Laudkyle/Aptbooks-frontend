export const CURRENCIES = [
  { code: 'GHS', name: 'Ghana Cedi' },
  { code: 'USD', name: 'US Dollar' },
  { code: 'EUR', name: 'Euro' },
  { code: 'GBP', name: 'British Pound' }
];
